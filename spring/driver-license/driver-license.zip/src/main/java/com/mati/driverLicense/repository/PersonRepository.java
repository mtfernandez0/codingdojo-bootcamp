package com.mati.driverLicense.repository;

import com.mati.driverLicense.entity.Person;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PersonRepository extends CrudRepository<Person, Long> {
    List<Person> findAll();

    @Override
    Optional<Person> findById(Long aLong);

    @Override
    boolean existsById(Long aLong);

    List<Person> findByLicenseIsNull();

//    @Query(value = "SELECT p.* FROM persons AS p LEFT OUTER JOIN licenses AS l ON p.id = l.person_id WHERE l.id IS NULL")
//    List<Person> findByLicenseIsNullNative();
}
