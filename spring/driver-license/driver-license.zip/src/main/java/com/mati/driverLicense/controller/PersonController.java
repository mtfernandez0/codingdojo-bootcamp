package com.mati.driverLicense.controller;

import com.mati.driverLicense.entity.Person;
import com.mati.driverLicense.service.LicenseService;
import com.mati.driverLicense.service.PersonService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
public class PersonController {

    private final PersonService personService;
    private final LicenseService licenseService;

    public PersonController(PersonService personService,
                            LicenseService licenseService) {
        this.personService = personService;
        this.licenseService = licenseService;
    }

    @GetMapping("/persons/new")
    public String newPersonsForm(@ModelAttribute("person") Person person){
        return "/person/new";
    }

    @PostMapping("/persons/new")
    public String newPerson(@Valid @ModelAttribute("person") Person person,
                            BindingResult result,
                            Model model){

        if (result.hasErrors()){
            model.addAttribute("person", person);
            return "/person/new";
        }

        Person personDB = personService.save(person);

        return "redirect:/persons/" + personDB.getId();
    }

    @GetMapping("/persons/{id}")
    public String showPerson(@PathVariable Long id,
                             Model model){
        Optional<Person> person;
        if ((person = personService.findById(id)).isPresent() && person.get().getLicense() != null){
            model.addAttribute("person", person.get());
            model.addAttribute("license_number",
                    generateAccountNumber(person.get().getId().intValue()));
        } else if (person.isEmpty())
            return "redirect:/persons/new";
        else
            return "redirect:/licenses/new";

        return "/person/showPerson";
    }

    private String generateAccountNumber(int number){
        StringBuilder accountNumber = new StringBuilder();
        int digits = String.valueOf(number).length();

        accountNumber.append("0".repeat(Math.max(0, 6 - digits)));

        accountNumber.append(number);
        return accountNumber.toString();
    }
}
