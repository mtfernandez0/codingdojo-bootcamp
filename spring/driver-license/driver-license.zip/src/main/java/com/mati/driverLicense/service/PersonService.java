package com.mati.driverLicense.service;

import com.mati.driverLicense.entity.License;
import com.mati.driverLicense.entity.Person;
import com.mati.driverLicense.repository.PersonRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PersonService {
    private final PersonRepository personRepository;

    public PersonService(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    public List<Person> findAll() {
        return personRepository.findAll();
    }

    public Person save(Person person){
        return personRepository.save(person);
    }

    public Optional<Person> findById(Long aLong) {
        return personRepository.findById(aLong);
    }

    public boolean existsById(Long aLong) {
        return personRepository.existsById(aLong);
    }

    public List<Person> findAllWithNullLicense(){
        return personRepository.findByLicenseIsNull();
    }
}
