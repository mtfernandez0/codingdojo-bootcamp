package com.mati.driverLicense.controller;

import com.mati.driverLicense.entity.License;
import com.mati.driverLicense.service.LicenseService;
import com.mati.driverLicense.service.PersonService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LicenseController {
    private final LicenseService licenseService;
    private final PersonService personService;

    public LicenseController(LicenseService licenseService,
                             PersonService personService) {
        this.licenseService = licenseService;
        this.personService = personService;
    }

    @GetMapping("/licenses/new")
    public String newPersonsForm(@ModelAttribute("license") License license,
                                 Model model){
        model.addAttribute("persons", personService.findAllWithNullLicense());
        return "/license/new";
    }

    @PostMapping("/licenses/new")
    public String newPerson(@Valid @ModelAttribute("license") License license,
                            BindingResult result,
                            Model model){
        if (result.hasErrors()){
            model.addAttribute("persons", personService.findAllWithNullLicense());
            model.addAttribute("license", license);
            return "/license/new";
        }

        License licenseDB = licenseService.save(license);

        return "redirect:/persons/" + licenseDB.getPerson().getId();
    }
}
