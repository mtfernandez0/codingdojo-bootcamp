package com.mati.driverLicense.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Entity
@Table(name = "licenses")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class License {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Integer number;
    @NotNull(message = "Expiration date cannot be empty")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date expiration_date;
    @NotBlank(message = "State cannot be empty")
    @Size(max = 255, message = "State must have a maximum of 255 characters")
    private String state;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "person_id")
    private Person person;

    @Column(updatable = false)
    private Date created_at;
    private Date updated_at;

    @PrePersist
    public void prePersist(){
        created_at = new Date();
        updated_at = new Date();
    }

    @PreUpdate
    public void preUpdate(){
        updated_at = new Date();
    }
}
