package com.mati.driverLicense.repository;

import com.mati.driverLicense.entity.License;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LicenseRepository extends CrudRepository<License, Long> {
    Optional<License> findTop1ByOrderByIdDesc();
}
