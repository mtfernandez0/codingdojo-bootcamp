package com.mati.driverLicense.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.Date;

@Entity
@Table(name = "persons")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "First name cannot be empty")
    @Size(max = 255, message = "First name must have a maximum of 255 characters")
    private String first_name;
    @NotBlank(message = "Last name cannot be empty")
    @Size(max = 255, message = "Last name must have a maximum of 255 characters")
    private String last_name;

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "person", fetch = FetchType.LAZY)
    private License license;

    @Column(updatable = false)
    private Date created_at;
    private Date updated_at;

    @PrePersist
    public void prePersist(){
        created_at = new Date();
        updated_at = new Date();
    }

    @PreUpdate
    public void preUpdate(){
        updated_at = new Date();
    }
}
