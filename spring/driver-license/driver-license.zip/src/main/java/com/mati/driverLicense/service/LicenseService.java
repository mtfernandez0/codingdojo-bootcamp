package com.mati.driverLicense.service;

import com.mati.driverLicense.entity.License;
import com.mati.driverLicense.repository.LicenseRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LicenseService {

    private final LicenseRepository licenseRepository;

    public LicenseService(LicenseRepository licenseRepository) {
        this.licenseRepository = licenseRepository;
    }

    public Long findGreatestIdOrOne(){
        Optional<License> license = licenseRepository.findTop1ByOrderByIdDesc();
        return license.isPresent() ? license.get().getId() : 1L;
    }

    public License save(License licence){
        licence.setNumber(findGreatestIdOrOne().intValue());
        return licenseRepository.save(licence);
    }
}
