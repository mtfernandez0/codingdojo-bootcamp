package com.mati.driverLicense;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriverLicenseApplicationTests {

    @Test
    void contextLoads() {
    }

}
