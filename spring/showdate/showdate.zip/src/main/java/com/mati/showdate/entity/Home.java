package com.mati.showdate.entity;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class Home {
    private static final String FORMAT_DATE = "EEEE, 'the' d 'of' MMMM, YYYY";
    private static final String FORMAT_TIME = "hh:mm, a";
    @RequestMapping("/")
    public String home(){
        return "home";
    }

    @RequestMapping("/date")
    public String showDate(Model model){
        String date = new SimpleDateFormat(FORMAT_DATE).format(new Date());
        model.addAttribute("date", date);
        return "date";
    }

    @RequestMapping("/time")
    public String showTime(Model model){
        String time = new SimpleDateFormat(FORMAT_TIME).format(new Date());
        model.addAttribute("time", time);
        return "time";
    }
}
