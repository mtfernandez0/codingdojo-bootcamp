package com.mati.showdate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowdateApplicationTests {

    @Test
    void contextLoads() {
    }

}
