package com.mati.loginauthentication.controller;

import com.mati.loginauthentication.entity.UserLogin;
import com.mati.loginauthentication.entity.User;
import com.mati.loginauthentication.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Objects;

@Controller
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/")
    public String redirect(){
        return "redirect:/dashboard";
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session){
        if (Objects.isNull(session.getAttribute("email")))
            return "redirect:/login";

        return "dashboard";
    }

    @GetMapping("/login")
    public String login(@ModelAttribute("user") UserLogin userLogin,
                        HttpSession session){
        return "login";
    }

    @PostMapping("/login")
    public String loginVerify(@Valid @ModelAttribute("user") UserLogin userLogin,
                              BindingResult result,
                              Model model,
                              HttpSession session){

        userService.checkCredentialsLogin(userLogin, result);

        if (result.hasErrors()){
            model.addAttribute("user", userLogin);
            return "login";
        }

        User user = userService.findByEmail(userLogin.getEmail());

        session.setAttribute("email", user.getEmail());

        return "redirect:/dashboard";
    }

    @GetMapping("/register")
    public String register(@ModelAttribute("user") User user){
        return "register";
    }

    @PostMapping("/register")
    public String registerVerify(@Valid @ModelAttribute("user") User user,
                                 BindingResult result,
                                 Model model){

        userService.checkCredentialsRegistration(user, result);

        if (result.hasErrors()){
            model.addAttribute("user", user);
            return "register";
        }

        userService.registerUser(user);

        return "redirect:/login";
    }

    @PostMapping("/logout")
    public String logout(HttpSession session){
        session.invalidate();

        return "redirect:/login";
    }
}
