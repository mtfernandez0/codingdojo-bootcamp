package com.mati.loginauthentication.service;

import com.mati.loginauthentication.entity.User;
import com.mati.loginauthentication.entity.UserLogin;
import com.mati.loginauthentication.repository.UserRepository;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import java.util.Objects;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User save(User user){
        return userRepository.save(user);
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public User registerUser(User user){
        user.setPassword(BCrypt.hashpw(user.getPassword(), BCrypt.gensalt()));
        return save(user);
    }

    public boolean checkCredentialsExistance(UserLogin user){
        return Objects.nonNull(user) &
                Objects.nonNull(user.getPassword()) &
                Objects.nonNull(user.getEmail());
    }


    public boolean checkCredentialsExistance(User user){
        return Objects.nonNull(user) &
                Objects.nonNull(user.getPassword()) &
                Objects.nonNull(user.getPasswordConfirmation()) &
                Objects.nonNull(user.getEmail());
    }

    public void checkCredentialsLogin(UserLogin user,
                                      BindingResult result){

        if (!checkCredentialsExistance(user)) return;

        User userDB;

        if (Objects.isNull(userDB = findByEmail(user.getEmail())) ||
                !BCrypt.checkpw(user.getPassword(), userDB.getPassword()))
            result.rejectValue(
                    "email",
                    "Matches",
                    "Email or password are not correct"
            );
    }

    public void checkCredentialsRegistration(User user,
                                             BindingResult result){

        if (!checkCredentialsExistance(user)) return;

        if (Objects.nonNull(findByEmail(user.getEmail())))
            result.rejectValue(
                    "email",
                    "Matches",
                    "Email already exists"
            );
        if (!user.getPassword().equals(user.getPasswordConfirmation()))
            result.rejectValue(
                    "password",
                    "Matches",
                    "Passwords doesn't coincide"
            );
    }
}
