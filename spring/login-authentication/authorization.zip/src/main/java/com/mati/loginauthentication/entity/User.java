package com.mati.loginauthentication.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.Date;

@Entity
@Table(name = "users")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Please insert an email")
    @Email(message = "The email is not valid")
    private String email;

    @NotBlank(message = "Please insert a password")
    @Size(min = 8, max = 64, message = "Password must be at least 8 characters long.")
    private String password;

    @Transient
    @NotBlank(message = "Please confirm your password")
    @Size(min = 8, max = 64, message = "Password must be at least 8 characters long.")
    private String passwordConfirmation;

    @Column(nullable = false)
    private Date created_at;

    private Date updated_at;

    @PrePersist
    private void prePersist(){
        this.created_at = new Date();
        this.updated_at = new Date();
    }

    @PreUpdate
    private void preUpdate(){
        this.updated_at = new Date();
    }
}
