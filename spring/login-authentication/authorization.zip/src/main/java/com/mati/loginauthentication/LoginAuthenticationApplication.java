package com.mati.loginauthentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginAuthenticationApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoginAuthenticationApplication.class, args);
    }

}
