package com.mati.loginauthentication.entity;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class UserLogin {
    @NotBlank(message = "Please insert an email")
    @Email(message = "The email is not valid")
    private String email;

    @NotBlank(message = "Please insert a password")
    @Size(min = 8, max = 64, message = "Password must be at least 8 characters long.")
    private String password;
}
