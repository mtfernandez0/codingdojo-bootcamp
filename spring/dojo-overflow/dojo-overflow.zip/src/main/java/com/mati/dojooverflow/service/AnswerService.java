package com.mati.dojooverflow.service;

import com.mati.dojooverflow.entity.Answer;
import com.mati.dojooverflow.entity.Question;
import com.mati.dojooverflow.repository.AnswerRepository;
import org.springframework.stereotype.Service;

@Service
public class AnswerService {

    private final AnswerRepository answerRepository;

    public AnswerService(AnswerRepository answerRepository) {
        this.answerRepository = answerRepository;
    }

    public Answer addQuestionToAnswer(Question question,
                                      Answer answer){
        answer.setQuestion(question);
        return save(answer);
    }

    public Answer save(Answer answer){
        return answerRepository.save(answer);
    }
}
