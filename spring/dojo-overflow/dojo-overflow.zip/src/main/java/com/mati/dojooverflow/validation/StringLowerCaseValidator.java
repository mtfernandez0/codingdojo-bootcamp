package com.mati.dojooverflow.validation;

import com.mati.dojooverflow.constraints.StringLowerCase;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class StringLowerCaseValidator implements ConstraintValidator<StringLowerCase, String> {
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) return true;

        String lowerCased = value.toLowerCase();
        return value.equals(lowerCased);
    }

    @Override
    public void initialize(StringLowerCase constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }
}
