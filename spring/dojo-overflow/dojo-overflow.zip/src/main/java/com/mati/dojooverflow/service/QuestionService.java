package com.mati.dojooverflow.service;

import com.mati.dojooverflow.entity.Question;
import com.mati.dojooverflow.entity.Tag;
import com.mati.dojooverflow.repository.QuestionRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class QuestionService {

    private final QuestionRepository questionRepository;

    private final TagService tagService;

    public QuestionService(QuestionRepository questionRepository, TagService tagService) {
        this.questionRepository = questionRepository;
        this.tagService = tagService;
    }

    public List<Question> findAll(){
        return questionRepository.findAll();
    }

    public void addQuestion(Question question, List<String> subjects){

        List<Tag> tags = generateTagList(subjects);

        Question questionDB = questionRepository.save(question);
        questionDB.setTags(new ArrayList<>());
        tagService.saveAll(tags).forEach(tag -> questionDB.getTags().add(tag));
        questionRepository.save(questionDB);
    }

    public boolean existsById(Long id) {
        return questionRepository.existsById(id);
    }

    public Optional<Question> findById(Long id) {
        return questionRepository.findById(id);
    }

    private List<Tag> generateTagList(List<String> subjects){

        List<Tag> tags = new ArrayList<>();

        subjects.forEach(subject -> {
            Tag tag;
            if ((tag = tagService.findBySubject(subject)) == null)
                tag = Tag.builder()
                        .subject(subject)
                        .questions(new ArrayList<>())
                        .build();
            tags.add(tag);
        });
        return tags;
    }
}
