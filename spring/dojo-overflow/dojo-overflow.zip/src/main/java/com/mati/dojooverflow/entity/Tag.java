package com.mati.dojooverflow.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "tags")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class Tag {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Subject must not be empty")
    @Size(max = 255, message = "Subject must have a maximum of 255 characters")
//    @StringLowerCase()
    @Pattern(regexp = "^[a-z0-9]{1,255}",
            message = "Subject can only contain lowercase characters and numbers")
    private String subject;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "tags_questions",
            joinColumns = @JoinColumn(name = "tag_id"),
            inverseJoinColumns = @JoinColumn(name = "question_id")
    )
    private List<Question> questions;

    @Column(nullable = false)
    private Date created_at;

    private Date updated_at;

    @PrePersist
    public void prePersist(){
        created_at = new Date();
        updated_at = new Date();
    }

    @PreUpdate
    public void preUpdate(){
        updated_at = new Date();
    }
}
