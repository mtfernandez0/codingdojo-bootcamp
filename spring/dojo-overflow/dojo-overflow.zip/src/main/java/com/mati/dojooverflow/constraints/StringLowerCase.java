package com.mati.dojooverflow.constraints;

import com.mati.dojooverflow.validation.StringLowerCaseValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ ElementType.FIELD, ElementType.PARAMETER})
@Constraint(validatedBy = StringLowerCaseValidator.class)
public @interface StringLowerCase {
    String message() default "The string not lowercase";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
