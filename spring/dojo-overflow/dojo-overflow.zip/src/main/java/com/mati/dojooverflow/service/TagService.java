package com.mati.dojooverflow.service;

import com.mati.dojooverflow.entity.Tag;
import com.mati.dojooverflow.repository.TagRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TagService {

    private final TagRepository tagRepository;

    public TagService(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }

    public Tag findBySubject(String subject) {
        return tagRepository.findBySubject(subject).orElse(null);
    }

    public Tag save(Tag tag) {
        return tagRepository.save(tag);
    }

    public Iterable<Tag> saveAll(List<Tag> tags) {
        return tagRepository.saveAll(tags);
    }
}
