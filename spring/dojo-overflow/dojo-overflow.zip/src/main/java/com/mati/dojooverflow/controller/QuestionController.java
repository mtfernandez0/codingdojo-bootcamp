package com.mati.dojooverflow.controller;

import com.mati.dojooverflow.entity.Answer;
import com.mati.dojooverflow.entity.Question;
import com.mati.dojooverflow.service.AnswerService;
import com.mati.dojooverflow.service.QuestionService;
import com.mati.dojooverflow.service.TagService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Controller
public class QuestionController {
    private final QuestionService questionService;
    private final AnswerService answerService;
    private final TagService tagService;

    public QuestionController(QuestionService questionService,
                              AnswerService answerService,
                              TagService tagService) {
        this.questionService = questionService;
        this.answerService = answerService;
        this.tagService = tagService;
    }

    @GetMapping("/")
    public String redirect(){
        return "redirect:/questions";
    }

    @GetMapping("/questions")
    public String dashboard(Model model){
        model.addAttribute("questions", questionService.findAll());
        return "question/dashboard";
    }

    @GetMapping("/questions/new")
    public String newQuestion(@ModelAttribute("ask") Question question){
        return "question/new";
    }

    @PostMapping("/questions/add")
    public String addQuestion(@Valid @ModelAttribute("ask") Question question,
                              BindingResult result,
                              @RequestParam("tags_form") String tags,
                              Model model){

        List<String> tagList = Arrays.asList(tags.split(","));
        tagList.replaceAll(String::trim);
        checkTagErrors(result, tagList);

        if (result.hasErrors()){
            model.addAttribute("ask", question);
            return "question/new";
        }

        questionService.addQuestion(question, tagList);

        return "redirect:/questions";
    }

    @GetMapping("/questions/{id}")
    public String questionProfile(@ModelAttribute("answer_obj") Answer answer,
                                  @PathVariable Long id,
                                  Model model){
        Optional<Question> question;
        if ((question = questionService.findById(id)).isEmpty())
            return "redirect:/questions/new";
        else
            model.addAttribute("question", question.get());

        return "question/profile";
    }

    @PostMapping("/questions/{question_id}/answer")
    public String addAnswer(@PathVariable Long question_id,
                            @Valid @ModelAttribute("answer_obj") Answer answer,
                            BindingResult result,
                            Model model){
        Optional<Question> question;
        if ((question = questionService.findById(question_id)).isEmpty())
            return "redirect:/questions";

        if (result.hasErrors()){
            model.addAttribute("question", question.get());
            model.addAttribute("answer_obj", answer);
            return "question/profile";
        }

        answerService.addQuestionToAnswer(question.get(), answer);

        return "redirect:/questions";
    }

    private void checkTagErrors(BindingResult result, List<String> subjects){
        boolean areLowerCase = true, areSizeCorrect = true;
        for (String subject : subjects)
            areLowerCase &= isLowerCase(subject);

        if (!areLowerCase)
            result.rejectValue(
                    "tags",
                    "lowercase",
                    "Tags must be in lowercase and cannot contain symbols"
            );

        for (String subject : subjects)
            areSizeCorrect &= subject.length() < 256;

        if (!areSizeCorrect)
            result.rejectValue(
                    "tags",
                    "size",
                    "Tags must have at most 255 characters"
            );

        if (subjects.size() > 3)
            result.rejectValue(
                    "tags",
                    "Maximum of 3 tags",
                    "You can only include uo to 3 tags");
    }

    private boolean isLowerCase(String value) {
        if (value == null) return true;

        String lowerCased = value.toLowerCase();
        return value.equals(lowerCased);
    }

}
