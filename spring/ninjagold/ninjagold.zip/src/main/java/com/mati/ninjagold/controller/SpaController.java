package com.mati.ninjagold.controller;

import jakarta.servlet.http.HttpSession;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Log4j2
public class SpaController {
    @PostMapping("/spa")
    public String spa(HttpSession session){
        int gold = (int)(Math.random()*16) + 5;
        gold = -gold;
        session.setAttribute("place", "spa");
        session.setAttribute("gold", gold);
        log.info("Gold spent at the spa: " + gold);
        return "redirect:/";
    }
}
