package com.mati.ninjagold.controller;

import jakarta.servlet.http.HttpSession;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Log4j2
public class FarmController {
    @PostMapping("/farm")
    public String farm(HttpSession session){
        int gold = (int)(Math.random()*11) + 10;
        session.setAttribute("place", "farm");
        session.setAttribute("gold", gold);
        log.info("Gold obtained from farm: " + gold);
        return "redirect:/";
    }
}
