package com.mati.ninjagold.controller;

import jakarta.servlet.http.HttpSession;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Log4j2
public class CaveController {
    @PostMapping("/cave")
    public String cave(HttpSession session){
        int gold = (int)(Math.random()*6) + 5;
        session.setAttribute("place", "cave");
        session.setAttribute("gold", gold);
        log.info("Gold obtained from cave: " + gold);
        return "redirect:/";
    }
}
