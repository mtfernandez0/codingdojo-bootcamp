package com.mati.ninjagold.controller;

import jakarta.servlet.http.HttpSession;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Log4j2
public class HouseController {
    @PostMapping("/house")
    public String house(HttpSession session){
        int gold = (int)(Math.random()*4) + 2;
        session.setAttribute("place", "house");
        session.setAttribute("gold", gold);
        log.info("Gold obtained from house: " + gold);
        return "redirect:/";
    }
}
