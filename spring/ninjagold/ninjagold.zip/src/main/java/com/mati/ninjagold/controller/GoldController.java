package com.mati.ninjagold.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;

@Controller
public class GoldController {
    LinkedHashMap<String, String> register;
    private int goldCount;
    private static final String PROFIT_MESSAGE_FORMAT = "You entered a %s and earned %d gold. (%s)";
    private static final String NO_CHANGES_MESSAGE_FORMAT =
            "You entered a %s and you did not win anything or lose anything. (%s)";
    private static final String LOST_MESSAGE_FORMAT = "You entered a %s and lost %d gold.. Ouch. (%s)";
    private static final String FORMAT_DATE = "MMMM d'%s' YYYY, hh:mm a";

    public GoldController() {
        this.register = new LinkedHashMap<>();
        goldCount = 0;
    }

    @GetMapping("/")
    public String gold(Model model, HttpSession session){
        if (session.getAttribute("place") != null){
            String place = (String) session.getAttribute("place");
            int goldFromPlace = (int) session.getAttribute("gold");

            String status;
            if (goldFromPlace > 0)
                status = "win";
            else if (goldFromPlace < 0)
                status = "lose";
            else
                status = "safe";

            goldCount += goldFromPlace;
            String message = getMessage(place, goldFromPlace);


            register.put(message, status);
            model.addAttribute("registers", register);
            session.removeAttribute("place");
            session.removeAttribute("gold");
            if (goldCount <= -150)
                return "redirect:/morosos";
        } else {
            clearVariables();
        }

        model.addAttribute("goldCount", goldCount);

        return "index";
    }

    @PostMapping("/reset")
    public String reset(){
        clearVariables();
        return "redirect:/";
    }

    @GetMapping("/morosos")
    public String morosos(){
        clearVariables();
        return "morosos";
    }

    private void clearVariables(){
        goldCount = 0;
        register.clear();
    }

    private String getMessage(String place, int gold){
        String date = getFormatDate();
        String message;
        if (gold > 0)
            message = String.format(PROFIT_MESSAGE_FORMAT, place, gold, date);
        else if (gold < 0)
            message = String.format(LOST_MESSAGE_FORMAT, place, gold, date);
        else
            message = String.format(NO_CHANGES_MESSAGE_FORMAT, place, date);

        return message;
    }

    private String getFormatDate(){
        LocalDateTime date = LocalDateTime.now();
        String termination = switch (date.getDayOfMonth() % 10) {
            case 1 -> "st";
            case 2 -> "nd";
            case 3 -> "rd";
            default -> "th";
        };

        String format = String.format(FORMAT_DATE, termination);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);

        return date.format(formatter);
    }
}