package com.mati.ninjagold.controller;

import jakarta.servlet.http.HttpSession;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Random;

@Controller
@Log4j2
public class CasinoController {
    @PostMapping("/casino")
    public String casino(HttpSession session){
        Random random = new Random();
        int gold = random.nextInt(101) - 50;
        session.setAttribute("place", "casino");
        session.setAttribute("gold", gold);
        log.info("Gold from casino: " + gold);
        return "redirect:/";
    }
}
