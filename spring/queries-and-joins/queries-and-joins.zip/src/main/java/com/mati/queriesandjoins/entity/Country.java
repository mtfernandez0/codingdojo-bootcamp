package com.mati.queriesandjoins.entity;

import com.mati.queriesandjoins.ContinentConverter;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "countries")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
public class Country {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, columnDefinition = "char(3) default ''")
    private String code;

    @Column(nullable = false, columnDefinition = "char(52) default ''")
    private String name;

    @Convert(converter = ContinentConverter.class)
    @Column(nullable = false, columnDefinition =
            "ENUM('Asia','Europe','North America','Africa','Oceania','Antarctica','South America') DEFAULT 'Asia'")
    private Continent continent;

    @Column(nullable = false, columnDefinition = "char(26) default ''")
    private String region;

    @Column(nullable = false, columnDefinition = "float(10, 2) default 0.00")
    private double surface_area;

    @Column(columnDefinition = "smallint")
    private short indep_year;

    @Column(nullable = false, columnDefinition = "int default 0")
    private Integer population;

    @Column(columnDefinition = "float(3, 1)")
    private double life_expectancy;

    @Column(columnDefinition = "float(10, 2)")
    private double gnp;

    @Column(columnDefinition = "float(10, 2)")
    private double gnp_old;

    @Column(nullable = false, columnDefinition = "char(45) default ''")
    private String local_name;

    @Column(nullable = false, columnDefinition = "char(45) default ''")
    private String government_form;

    @Column(columnDefinition = "char(60)")
    private String head_of_state;

    private Integer capital;

    @Column(nullable = false, columnDefinition = "char(2) default ''")
    private String code2;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "country")
    private List<City> cities;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "country")
    private List<Language> languages;
}
