package com.mati.queriesandjoins.controller;

import com.mati.queriesandjoins.service.ApiService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ApiController {

    private final ApiService apiService;

    public ApiController(ApiService apiService) {
        this.apiService = apiService;
    }

    @GetMapping("/exercises/{exercise}")
    public List<Object[]> displayQueryResults(@PathVariable Integer exercise){
        return switch (exercise) {
            case 1 -> apiService.getInfoCountryWhereLanguageSlovene();
            case 2 -> apiService.getNumberCitiesPerCountry();
            case 3 -> apiService.getCitiesFromMexicoPopulationOver();
            case 4 -> apiService.getCountiesLanguagePercentageOver();
            case 5 -> apiService.getCountriesSurfaceAreaANdPopulationConstraints();
            case 6 -> apiService.getCountriesGovernmentSurfaceLifeConstraints();
            case 7 -> apiService.getArgentineDistrictsPopulationConstraints();
            default -> apiService.getCountriesCountByRegion();
        };
    }
}
