package com.mati.queriesandjoins.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "cities")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class City {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull
    @Column(columnDefinition = "char(35) default ''")
    private String name;

    @NotNull
    @Column(columnDefinition = "char(3) default ''")
    private String country_code;

    @NotNull
    @Column(columnDefinition = "char(20) default ''")
    private String district;

    @NotNull
    @Column(columnDefinition = "int default 0")
    private Integer population;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "country_id")
    private Country country;
}
