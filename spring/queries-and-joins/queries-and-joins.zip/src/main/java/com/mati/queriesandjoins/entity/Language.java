package com.mati.queriesandjoins.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "languages")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Language {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, columnDefinition = "char(3) default ''")
    private String country_code;

    @Column(nullable = false, columnDefinition = "char(30) default ''")
    private String language;

    @Column(nullable = false, columnDefinition = "ENUM('T', 'F') DEFAULT 'F'")
    private Official is_official;

    @Column(nullable = false, columnDefinition = "float(4, 1) default 0.0")
    private double percentage;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "country_id")
    private Country country;
}
