package com.mati.queriesandjoins.entity;

public enum Official {
    T, F
}
