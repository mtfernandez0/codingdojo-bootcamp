package com.mati.queriesandjoins.entity;

public enum Continent {
    ASIA("Asia"),
    EUROPE("Europe"),
    NORTH_AMERICA("North_America"),
    AFRICA("Africa"),
    OCEANIA("Oceania"),
    ANTARTICA("Antarctica"),
    SOUTH_AFRICA("South_America");

    private final String continent;

    Continent(String continent) {
        this.continent = continent;
    }

    public String getContinent() {
        return continent;
    }
}
