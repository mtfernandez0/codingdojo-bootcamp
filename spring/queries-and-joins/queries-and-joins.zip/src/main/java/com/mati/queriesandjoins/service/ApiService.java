package com.mati.queriesandjoins.service;

import com.mati.queriesandjoins.repository.CityRepository;
import com.mati.queriesandjoins.repository.CountryRepository;
import com.mati.queriesandjoins.repository.LanguageRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApiService {

    private final CountryRepository countryRepository;

    private final CityRepository cityRepository;

    private final LanguageRepository languageRepository;

    public ApiService(CountryRepository countryRepository,
                      CityRepository cityRepository,
                      LanguageRepository languageRepository) {
        this.countryRepository = countryRepository;
        this.cityRepository = cityRepository;
        this.languageRepository = languageRepository;
    }

    public List<Object[]> getInfoCountryWhereLanguageSlovene() {
        return countryRepository.getInfoCountryWhereLanguageSlovene();
    }

    public List<Object[]> getNumberCitiesPerCountry() {
        return countryRepository.getNumberCitiesPerCountry();
    }

    public List<Object[]> getCitiesFromMexicoPopulationOver() {
        return countryRepository.getCitiesFromMexicoPopulationOver();
    }

    public List<Object[]> getCountiesLanguagePercentageOver() {
        return countryRepository.getCountiesLanguagePercentageOver();
    }

    public List<Object[]> getCountriesSurfaceAreaANdPopulationConstraints() {
        return countryRepository.getCountriesSurfaceAreaANdPopulationConstraints();
    }

    public List<Object[]> getCountriesGovernmentSurfaceLifeConstraints() {
        return countryRepository.getCountriesGovernmentSurfaceLifeConstraints();
    }

    public List<Object[]> getArgentineDistrictsPopulationConstraints() {
        return countryRepository.getArgentineDistrictsPopulationConstraints();
    }

    public List<Object[]> getCountriesCountByRegion() {
        return countryRepository.getCountriesCountByRegion();
    }
}
