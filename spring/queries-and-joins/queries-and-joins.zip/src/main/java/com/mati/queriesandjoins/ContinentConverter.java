package com.mati.queriesandjoins;

import com.mati.queriesandjoins.entity.Continent;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter
public class ContinentConverter implements AttributeConverter<Continent, String> {
    @Override
    public String convertToDatabaseColumn(Continent attribute) {
        return attribute.getContinent();
    }

    @Override
    public Continent convertToEntityAttribute(String dbData) {
        for (Continent continent: Continent.values()) {
            if (continent.getContinent().equals(dbData))
                return continent;
        }
        throw new IllegalArgumentException("Couldn't find an according representation");
    }
}
