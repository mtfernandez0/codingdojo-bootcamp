package com.mati.queriesandjoins.repository;

import com.mati.queriesandjoins.entity.Country;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CountryRepository extends CrudRepository<Country, Integer> {

    @Query(
            value = "SELECT c.name, l.language, COUNT(ci.id) AS cities_per_country " +
                    "FROM countries AS c " +
                    "JOIN languages AS l ON l.country_id = c.id " +
                    "JOIN cities AS ci ON ci.country_id = c.id " +
                    "WHERE l.language = 'Slovene' " +
                    "GROUP BY c.name " +
                    "ORDER BY cities_per_country DESC",
            nativeQuery = true
    )
    List<Object[]> getInfoCountryWhereLanguageSlovene();


    @Query(
            value = "SELECT c.name, COUNT(ci.id) AS total_cities " +
                    "FROM countries AS c " +
                    "LEFT JOIN cities AS ci ON ci.country_id = c.id " +
                    "GROUP BY c.name " +
                    "ORDER BY total_cities DESC",
            nativeQuery = true
    )
    List<Object[]> getNumberCitiesPerCountry();

    @Query(
            value = "SELECT ci.name, ci.population " +
                    "FROM cities AS ci " +
                    "JOIN countries AS c ON ci.country_id = c.id " +
                    "WHERE c.name = 'Mexico' AND ci.population >= 500000 " +
                    "ORDER BY c.population DESC",
            nativeQuery = true
    )
    List<Object[]> getCitiesFromMexicoPopulationOver();

    @Query(
            value = "SELECT c.name, l.language, l.percentage " +
                    "FROM countries AS c " +
                    "JOIN languages AS l ON l.country_id = c.id " +
                    "WHERE l.percentage > 89 " +
                    "ORDER BY l.percentage DESC",
            nativeQuery = true
    )
    List<Object[]> getCountiesLanguagePercentageOver();

    @Query(
            value = "SELECT name, surface_area, population " +
                    "FROM countries " +
                    "WHERE surface_area < 501 AND population > 100000",
            nativeQuery = true
    )
    List<Object[]> getCountriesSurfaceAreaANdPopulationConstraints();

    @Query(
            value = "SELECT name, government_form, surface_area, life_expectancy " +
                    "FROM countries " +
                    "WHERE government_form LIKE '%Constitutional Monarchy%' " +
                    "AND surface_area > 200 AND life_expectancy > 75",
            nativeQuery = true
    )
    List<Object[]> getCountriesGovernmentSurfaceLifeConstraints();

    @Query(
            value = "SELECT c.name, ci.name, ci.district, ci.population " +
                    "FROM countries AS c " +
                    "JOIN cities AS ci " +
                    "WHERE c.name = 'Argentina' AND ci.district = 'Buenos Aires' AND ci.population > 500000",
            nativeQuery = true
    )
    List<Object[]> getArgentineDistrictsPopulationConstraints();

    @Query(
            value = "SELECT region, COUNT(id) AS countries_in_region " +
                    "FROM countries " +
                    "GROUP BY region " +
                    "ORDER BY countries_in_region DESC",
            nativeQuery = true
    )
    List<Object[]> getCountriesCountByRegion();
}
