package com.mati.queriesandjoins.repository;

import com.mati.queriesandjoins.entity.Country;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CountryRepository extends CrudRepository<Country, Integer> {

    @Query(
            value = "SELECT c.name, l.language, COUNT(ci.id) AS cities_per_country " +
                    "FROM Country AS c " +
                    "JOIN Language AS l ON l.country.id = c.id " +
                    "JOIN City AS ci ON ci.country.id = c.id " +
                    "WHERE l.language = 'Slovene' " +
                    "GROUP BY c.name " +
                    "ORDER BY cities_per_country DESC"
    )
    List<Object[]> getInfoCountryWhereLanguageSlovene();

    @Query(
            value = "SELECT c.name, COUNT(ci.id) AS total_cities " +
                    "FROM Country AS c " +
                    "LEFT JOIN City AS ci ON ci.country.id = c.id " +
                    "GROUP BY c.name " +
                    "ORDER BY total_cities DESC"
    )
    List<Object[]> getNumberCitiesPerCountry();

    @Query(
            value = "SELECT ci.name, ci.population " +
                    "FROM City AS ci " +
                    "JOIN Country AS c ON ci.country.id = c.id " +
                    "WHERE c.name = 'Mexico' AND ci.population >= 500000 " +
                    "ORDER BY c.population DESC"
    )
    List<Object[]> getCitiesFromMexicoPopulationOver();

    @Query(
            value = "SELECT c.name, l.language, l.percentage " +
                    "FROM Country AS c " +
                    "JOIN Language AS l ON l.country.id = c.id " +
                    "WHERE l.percentage > 89 " +
                    "ORDER BY l.percentage DESC"
    )
    List<Object[]> getCountiesLanguagePercentageOver();

    @Query(
            value = "SELECT name, surface_area, population " +
                    "FROM Country " +
                    "WHERE surface_area < 501 AND population > 100000"
    )
    List<Object[]> getCountriesSurfaceAreaANdPopulationConstraints();

    @Query(
            value = "SELECT name, government_form, surface_area, life_expectancy " +
                    "FROM Country " +
                    "WHERE government_form LIKE '%Constitutional Monarchy%' " +
                    "AND surface_area > 200 AND life_expectancy > 75"
    )
    List<Object[]> getCountriesGovernmentSurfaceLifeConstraints();

    @Query(
            value = "SELECT c.name, ci.name, ci.district, ci.population " +
                    "FROM Country AS c " +
                    "JOIN City AS ci ON c.id = ci.country.id " +
                    "WHERE c.name = 'Argentina' AND ci.district = 'Buenos Aires' AND ci.population > 500000"
    )
    List<Object[]> getArgentineDistrictsPopulationConstraints();

    @Query(
            value = "SELECT region, COUNT(id) AS countries_in_region " +
                    "FROM Country  " +
                    "GROUP BY region " +
                    "ORDER BY countries_in_region DESC"
    )
    List<Object[]> getCountriesCountByRegion();
}
