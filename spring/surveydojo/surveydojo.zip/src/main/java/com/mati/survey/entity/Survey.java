package com.mati.survey.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
public class Survey {
    private String name;
    private String location;
    private String language;
    private String comment;
}
