package com.mati.survey.controller;

import com.mati.survey.entity.Survey;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Home {
    public Survey survey;

    public Home() {
        this.survey = new Survey();
    }

    @GetMapping("/")
    public String index(){
        return "index";
    }

    @PostMapping("/saveInfo")
    public String saveInfo(@RequestParam String name, @RequestParam String location,
                           @RequestParam String language, @RequestParam String comment){
        survey.setName(name);
        survey.setLanguage(language);
        survey.setLocation(location);
        survey.setComment(comment);

        if (language != null && language.equals("Java"))
            return "redirect:/javalovers";

        return "redirect:/result";
    }

    @GetMapping("/result")
    public String surveyData(Model model){
        model.addAttribute("name", survey.getName());
        model.addAttribute("language", survey.getLanguage());
        model.addAttribute("location", survey.getLocation());
        model.addAttribute("comment", survey.getComment());
        return "surveydata";
    }

    @GetMapping("/javalovers")
    public String javalovers(){
        return "javalovers";
    }
}
