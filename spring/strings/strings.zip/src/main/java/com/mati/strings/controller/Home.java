package com.mati.strings.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Home {
    @GetMapping("/")
    public String hello(){
        return "Today's a good day, at least for me, I don't know about you, nor do I know you.";
    }

    @GetMapping("/random")
    public String random(){
        return "Yesterday was a good day, at least for Spring Boot, my day wasn't good, my mate got cold.";
    }
}