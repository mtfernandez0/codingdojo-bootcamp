package com.mati.dojosandninjas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojonAndNinjasApplication {

    public static void main(String[] args) {
        SpringApplication.run(DojonAndNinjasApplication.class, args);
    }

}
