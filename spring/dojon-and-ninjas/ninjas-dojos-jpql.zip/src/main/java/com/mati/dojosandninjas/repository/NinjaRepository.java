package com.mati.dojosandninjas.repository;

import com.mati.dojosandninjas.entity.Ninja;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NinjaRepository extends CrudRepository<Ninja, Long>, PagingAndSortingRepository<Ninja, Long> {
    List<Ninja> findAllByDojo_Id(Long id);

    @Query("SELECT d, n " +
            "FROM Dojo AS d " +
            "JOIN d.ninjas AS n ON n.dojo.id = d.id " +
            "ORDER BY d.name ASC")
    Page<Object[]> getDojosAndNinjas(Pageable pageRequest);

    @Override
    long count();
}
