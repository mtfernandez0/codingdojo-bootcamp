package com.mati.dojosandninjas.service;

import com.mati.dojosandninjas.entity.Dojo;
import com.mati.dojosandninjas.repository.DojoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DojoService {

    private final DojoRepository dojoRepository;

    public DojoService(DojoRepository dojoRepository) {
        this.dojoRepository = dojoRepository;
    }

    public Optional<Dojo> findById(Long id) {
        return dojoRepository.findById(id);
    }

    public Dojo save(Dojo entity) {
        return dojoRepository.save(entity);
    }

    public List<Dojo> findAll() {
        return dojoRepository.findAll();
    }
}
