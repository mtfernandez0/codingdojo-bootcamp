package com.mati.dojosandninjas.entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "dojos")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class, property="@id")
public class Dojo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Name must not be empty")
    @Size(max = 255, message = "Name must be at most 255 characters")
    private String name;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "dojo")
    private Set<Ninja> ninjas;

    @Column(updatable = false)
    private Date created_at;
    private Date updated_at;

    @PrePersist
    public void prePersist(){
        created_at = new Date();
        updated_at = new Date();
    }

    @PreUpdate
    public void preUpdate(){
        updated_at = new Date();
    }
}
