package com.mati.dojosandninjas.service;

import com.mati.dojosandninjas.entity.Ninja;
import com.mati.dojosandninjas.repository.NinjaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NinjaService {

    private final NinjaRepository ninjaRepository;
    private static final int PAGE_SIZE = 5;

    public NinjaService(NinjaRepository ninjaRepository) {
        this.ninjaRepository = ninjaRepository;
    }

    public <S extends Ninja> S save(S entity) {
        return ninjaRepository.save(entity);
    }

    public Page<Object[]> ninjasAndDojos(int pageNumber){
        Pageable pageRequest = PageRequest.of(
                pageNumber - 1,
                PAGE_SIZE);

        return ninjaRepository.getDojosAndNinjas(pageRequest);
    }

    public int numberOfPages(){
        return (int)Math.ceil((double)ninjaRepository.count() / (double)PAGE_SIZE);
    }

    public List<Ninja> findAllByDojo_Id(Long id) {
        return ninjaRepository.findAllByDojo_Id(id);
    }
}
