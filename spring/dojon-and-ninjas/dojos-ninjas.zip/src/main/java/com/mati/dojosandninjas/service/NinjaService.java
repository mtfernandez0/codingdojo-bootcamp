package com.mati.dojosandninjas.service;

import com.mati.dojosandninjas.entity.Ninja;
import com.mati.dojosandninjas.repository.NinjaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NinjaService {

    private final NinjaRepository ninjaRepository;

    public NinjaService(NinjaRepository ninjaRepository) {
        this.ninjaRepository = ninjaRepository;
    }

    public <S extends Ninja> S save(S entity) {
        return ninjaRepository.save(entity);
    }

    public List<Ninja> findAllByDojo_Id(Long id) {
        return ninjaRepository.findAllByDojo_Id(id);
    }
}
