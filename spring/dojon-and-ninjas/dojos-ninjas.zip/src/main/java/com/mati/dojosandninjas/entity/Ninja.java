package com.mati.dojosandninjas.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.validator.constraints.Range;

import java.util.Date;

@Entity
@Table(name = "ninjas")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class Ninja {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Name must not be empty")
    @Size(max = 255, message = "Name must be at most 255 characters")
    private String first_name;

    @NotBlank(message = "Last name must not be empty")
    @Size(max = 255, message = "Last name must be at most 255 characters")
    private String last_name;

    @NotNull(message = "Age must not be empty")
    @Range(min = 1, max = 120, message = "Age must be between 1 and 120")
    private Integer age;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dojos_id")
    private Dojo dojo;

    @Column(updatable = false)
    private Date created_at;
    private Date updated_at;

    @PrePersist
    public void prePersist(){
        created_at = new Date();
        updated_at = new Date();
    }

    @PreUpdate
    public void preUpdate(){
        updated_at = new Date();
    }
}
