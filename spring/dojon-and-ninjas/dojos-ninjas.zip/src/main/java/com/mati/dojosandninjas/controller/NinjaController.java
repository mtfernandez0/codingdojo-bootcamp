package com.mati.dojosandninjas.controller;

import com.mati.dojosandninjas.entity.Ninja;
import com.mati.dojosandninjas.service.DojoService;
import com.mati.dojosandninjas.service.NinjaService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class NinjaController {
    private final NinjaService ninjaService;
    private final DojoService dojoService;

    public NinjaController(NinjaService ninjaService, DojoService dojoService) {
        this.ninjaService = ninjaService;
        this.dojoService = dojoService;
    }

    @GetMapping("/ninjas/new")
    public String ninjasNew(@ModelAttribute("ninja") Ninja ninja,
                            Model model){
        model.addAttribute("dojos", dojoService.findAll());
        return "ninja/new";
    }

    @PostMapping("/ninjas/create")
    public String ninjasCreate(@Valid @ModelAttribute("ninja") Ninja ninja,
                               BindingResult result,
                               Model model){
        if (result.hasErrors()){
            model.addAttribute("dojos", dojoService.findAll());
            model.addAttribute("ninja", ninja);
            return "ninja/new";
        }

        Ninja ninjaDB = ninjaService.save(ninja);

        return "redirect:/dojos/" + ninjaDB.getDojo().getId();
    }
}
