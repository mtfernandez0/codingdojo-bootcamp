package com.mati.studentslist.service;

import com.mati.studentslist.entity.Contact;
import com.mati.studentslist.entity.Student;
import com.mati.studentslist.repository.ContactRepository;
import com.mati.studentslist.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ApiService {

    private final StudentRepository studentRepository;
    private final ContactRepository contactRepository;

    public ApiService(StudentRepository studentRepository, ContactRepository contactRepository) {
        this.studentRepository = studentRepository;
        this.contactRepository = contactRepository;
    }

    public Optional<Student> findById(Long id) {
        return studentRepository.findById(id);
    }

    public List<Student> findAllWithContact(){
        return studentRepository.findByContactIsNotNull();
    }

    public List<Student> findAll() {
        return studentRepository.findAll();
    }

    public Student save(Student student) {
        return studentRepository.save(student);
    }

    public Contact save(Contact contact) {
        return contactRepository.save(contact);
    }
}
