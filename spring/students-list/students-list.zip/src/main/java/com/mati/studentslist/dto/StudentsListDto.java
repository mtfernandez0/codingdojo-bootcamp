package com.mati.studentslist.dto;

import java.util.ArrayList;
import java.util.List;

public class StudentsListDto {
    private List<StudentDto> students = new ArrayList<>();

    public StudentsListDto() {}

    public List<StudentDto> getStudents() {
        return students;
    }

    public void setStudents(List<StudentDto> students) {
        this.students = students;
    }
}
