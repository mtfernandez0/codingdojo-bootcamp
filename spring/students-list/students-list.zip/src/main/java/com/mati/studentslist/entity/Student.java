package com.mati.studentslist.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.validator.constraints.Range;

import java.util.Date;

@Entity
@Table(name = "students")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "First name cannot be empty")
    @Size(max = 255, message = "First name must have a maximum of 255 characters")
    private String firstName;
    @NotBlank(message = "Last name cannot be empty")
    @Size(max = 255, message = "Last name must have a maximum of 255 characters")
    private String lastName;
    @NotNull(message = "The age must not be empty")
    @Range(min = 1, max = 120, message = "A student's age must be between 1 and 120 years old")
    private Integer age;

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "student", fetch = FetchType.LAZY)
    private Contact contact;

    @Column(updatable = false)
    private Date created_at;
    private Date updated_at;

    @PrePersist
    public void prePersist(){
        created_at = new Date();
        updated_at = new Date();
    }

    @PreUpdate
    public void preUpdate(){
        updated_at = new Date();
    }
}
