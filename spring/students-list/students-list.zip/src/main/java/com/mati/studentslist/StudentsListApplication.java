package com.mati.studentslist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsListApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentsListApplication.class, args);
    }

}
