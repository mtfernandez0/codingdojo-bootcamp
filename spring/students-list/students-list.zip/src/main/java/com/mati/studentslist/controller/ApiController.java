package com.mati.studentslist.controller;

import com.mati.studentslist.dto.StudentDto;
import com.mati.studentslist.dto.StudentsListDto;
import com.mati.studentslist.entity.Contact;
import com.mati.studentslist.entity.Student;
import com.mati.studentslist.service.ApiService;
import jakarta.validation.Valid;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@Log4j2
@RequestMapping("/api")
public class ApiController {

    private final ApiService apiService;

    public ApiController(ApiService apiService) {
        this.apiService = apiService;
    }

    @GetMapping("/students")
    public ResponseEntity<StudentsListDto> students(){
        List<Student> students = apiService.findAllWithContact();
        StudentsListDto studentsListDto = new StudentsListDto();
        students.forEach(student -> {
            studentsListDto.getStudents()
                    .add(new StudentDto().buildDto(student, student.getContact()));
        });
        return ResponseEntity.ok(studentsListDto);
    }

    @PostMapping("/students/create")
    public ResponseEntity createStudent(@Valid @ModelAttribute("student") Student student,
                                        BindingResult result){
        if (result.hasErrors()){
            List<String> messages = new ArrayList<>();
            result.getAllErrors().forEach(objectError -> messages.add(objectError.getDefaultMessage()));
            return ResponseEntity.badRequest().body(messages);
        }

        Student studentDB = apiService.save(student);
        return ResponseEntity.ok(studentDB);
    }

    @PostMapping("/contacts/create")
    public ResponseEntity createContact(@Valid @ModelAttribute("contact") Contact contact,
                                        BindingResult result){
        if (result.hasErrors() || !isAvailableToCreateContact(contact.getStudent())){
            List<String> messages = new ArrayList<>();
            result.getAllErrors().forEach(objectError -> messages.add(objectError.getDefaultMessage()));
            if (!isAvailableToCreateContact(contact.getStudent()))
                messages.add("The student id must be valid");
            return ResponseEntity.badRequest().body(messages);
        }

        Contact contactDB = apiService.save(contact);
        return ResponseEntity.ok(contactDB);
    }

    private boolean isAvailableToCreateContact(Student student){
        return student != null && student.getContact() == null;
    }
}

