package com.mati.studentslist.dto;

import com.mati.studentslist.entity.Contact;
import com.mati.studentslist.entity.Student;
import lombok.*;

@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class StudentDto {
    private String name;
    private Integer age;
    private String address;
    private String city;
    private String state;

    public StudentDto buildDto(Student student,
                               Contact contact){
        return StudentDto.builder()
                .name(student.getFirstName() + " " + student.getLastName())
                .age(student.getAge())
                .address(contact.getAddress())
                .city(contact.getCity())
                .state(contact.getState()).build();
    }
}
