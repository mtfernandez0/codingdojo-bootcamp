package com.mati.hellohuman.entity;

import org.springframework.web.bind.annotation.*;

@RestController
public class Greeting {
    @RequestMapping("/")
    public String greet(@RequestParam(name = "name", required = false) String name,
                        @RequestParam(name = "lastname", required = false) String lastname){
        String body = "";

        if (name == null && lastname == null)
            body += "Human";
        if(name != null)
            body += name;
        if(lastname != null)
            body += " " + lastname;

        return "<h1>Hello " + body + "!</h1></br>Welcome to SpringBoot!";
    }
}
