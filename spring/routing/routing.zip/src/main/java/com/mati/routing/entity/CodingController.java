package com.mati.routing.entity;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/coding")
public class CodingController {
    @RequestMapping(value = "/")
    public String root(){
        return "¡Hola Coding Dojo!";
    }

    @RequestMapping(value = "/python")
    public String python(){
        return "¡Python/Django fue increíble!";
    }

    @RequestMapping(value = "/java")
    public String java(){
        return "¡Java/Spring es mejor!";
    }
}
