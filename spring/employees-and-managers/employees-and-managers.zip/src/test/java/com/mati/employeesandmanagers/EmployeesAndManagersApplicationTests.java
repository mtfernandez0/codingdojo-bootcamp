package com.mati.employeesandmanagers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeesAndManagersApplicationTests {

    @Test
    void contextLoads() {
    }

}
