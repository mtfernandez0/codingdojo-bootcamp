package com.mati.employeesandmanagers.service;

import com.mati.employeesandmanagers.entity.Employee;
import com.mati.employeesandmanagers.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public Employee findById(Integer id){
        return employeeRepository.findById(id).orElse(null);
    }

    /**
     * Returns the list of employees of the given manager_id
     * @param manager_id
     * @return The list of employees of the given manager_id, or an empty list
     * if the manager doesn't exists
     */
    public List<Employee> getEmployeesFromManager(Integer manager_id){
        Employee manager = findById(manager_id);

        return manager == null ? new ArrayList<>() : manager.getEmployees();
    }

    /**
     * Returns the manager of the given employee_id
     * @param employee_id
     * @return The manager of the given employee_id, or null whether the employee
     * or manager was not found
     */
    public Employee getManagerFromEmployee(Integer employee_id){
        Employee employee = findById(employee_id);

        return employee != null ? employee.getManager_id() : null;
    }

    public Employee save(Employee employee){
        return employeeRepository.save(employee);
    }

    public boolean existsById(Integer id){
        return employeeRepository.existsById(id);
    }

    /**
     * Sets the manager of the employee with the given by parameter and adds the employee to the list
     * of employees of the manager given by parameter
     * @param employee_id
     * @param manager_id
     * @return updated employee with manager or the same employee if the manager was the same
     */
    public Employee addEmployeeAndSave(Integer employee_id, Integer manager_id){
        Employee employee = findById(employee_id);
        Employee manager = findById(manager_id);

        if (employee.getManager_id() == null || !Objects.equals(employee.getManager_id().getId(), manager.getId())){
            manager.getEmployees().add(employee);
            employee.setManager_id(manager);
            save(employee);
        }

        return employee;
    }
}
