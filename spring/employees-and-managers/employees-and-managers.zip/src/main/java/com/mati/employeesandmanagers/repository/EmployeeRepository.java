package com.mati.employeesandmanagers.repository;

import com.mati.employeesandmanagers.entity.Employee;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

    @Override
    Optional<Employee> findById(Integer integer);
}
