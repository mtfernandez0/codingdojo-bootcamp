package com.mati.employeesandmanagers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeesAndManagersApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeesAndManagersApplication.class, args);
    }

}
