package com.mati.employeesandmanagers.entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "employees")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class, property="@id")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank
    @Size(min = 3, max = 255)
    private String first_name;

    @NotBlank
    @Size(min = 3, max = 255)
    private String last_name;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "manager_id")
    private Employee manager_id;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "manager_id")
    private List<Employee> employees;

    @Column(nullable = false)
    private Date created_at;

    private Date updated_at;

    @PrePersist
    private void prePersist(){
        this.created_at = new Date();
        this.updated_at = new Date();
    }

    @PreUpdate
    private void preUpdate(){
        this.updated_at = new Date();
    }
}
