package com.mati.employeesandmanagers.controller;

import com.mati.employeesandmanagers.entity.Employee;
import com.mati.employeesandmanagers.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping("/manager/{employee_id}")
    public Employee getManagerFromEmployee(@PathVariable Integer employee_id){
        return employeeService.getManagerFromEmployee(employee_id);
    }

    /**
     * Send data in a json object, for example:
     * {
     *      "first_name": "name",
     *      "last_name": "last name"
     * }
     * @param employee
     * @return
     */
    @PostMapping("/employees/add/employee")
    public ResponseEntity<?> createEmployee(@Valid @RequestBody Employee employee){
        if (employee.getId() != null)
            return ResponseEntity.badRequest().body("Wasn't expecting attribute 'id'");

        Employee employeeDB = employeeService.save(employee);

        return ResponseEntity.ok(employeeDB);
    }

    @PutMapping("/employees/add/manager")
    public ResponseEntity<?> setManager(@RequestParam Integer employee_id,
                                        @RequestParam Integer manager_id){
        if (!employeeService.existsById(employee_id) || !employeeService.existsById(manager_id))
            return ResponseEntity.badRequest().body("The id inserted is not valid");

        Employee employeeDB = employeeService.addEmployeeAndSave(employee_id, manager_id);

        return ResponseEntity.ok(employeeDB);
    }

    @GetMapping("/employees/{manager_id}")
    public List<Employee> getEmployeesFromManager(@PathVariable Integer manager_id){
        return employeeService.getEmployeesFromManager(manager_id);
    }
}
