package com.mati.thecode.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class Home {
    private String hash;

    @GetMapping("/")
    public String home(){
        return "index";
    }

    @PostMapping("/checkCode")
    public String checkCode(@RequestParam String code, RedirectAttributes redirectAttributes){
        if (!code.equals("bushido")){
            redirectAttributes.addFlashAttribute("error", "You must train harder!");
            return "redirect:/";
        }
        hash = generateRandomString64();
        redirectAttributes.addFlashAttribute("access", hash);
        return "redirect:/code";
    }

    /**
     * You can access this page only once before having to insert the code again.
     * @param model
     * @return
     */
    @GetMapping("/code")
    public String code(Model model){
        String access = (String) model.getAttribute("access");
        if (access == null || !access.equals(hash))
            return "redirect:/";
        return "code";
    }

    private String generateRandomString64(){
        String values = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < 64; i++){
            res.append(values.charAt((int) (Math.random() * values.length())));
        }
        return res.toString();
    }
}
