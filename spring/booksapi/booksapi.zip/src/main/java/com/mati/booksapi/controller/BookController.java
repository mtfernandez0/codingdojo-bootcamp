package com.mati.booksapi.controller;

import com.mati.booksapi.entity.Book;
import com.mati.booksapi.service.BookService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class BookController {
    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/books")
    public List<Book> books(){
        return bookService.findAll();
    }

    @PostMapping("/books")
    public Book create(@RequestParam(value="title") String title,
                       @RequestParam(value="description") String desc,
                       @RequestParam(value="language") String lang,
                       @RequestParam(value="pages") Integer numOfPages) {
        Book book = Book.builder()
                .title(title).description(desc).language(lang).numberOfPages(numOfPages).build();
        return bookService.save(book);
    }

    @GetMapping("/books/{id}")
    public Book bookById(@PathVariable Long id){
        return bookService.findById(id);
    }

    @PutMapping(value="/books/{id}")
    public Book update(@PathVariable("id") Long id, @RequestParam(value="title") String title,
                       @RequestParam(value="description") String desc, @RequestParam(value="language") String lang,
                       @RequestParam(value="pages") Integer numOfPages) {
        return bookService.updateBook(id, title, desc, lang, numOfPages);
    }

    @DeleteMapping(value="/books/{id}")
    public void destroy(@PathVariable("id") Long id) {
        bookService.deleteBook(id);
    }

}
