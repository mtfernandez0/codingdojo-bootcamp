package com.mati.booksapi.controller;

import com.mati.booksapi.entity.Book;
import com.mati.booksapi.service.BookService;
import jakarta.validation.Valid;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@Log4j2
public class BookWebController {
    private final BookService bookService;

    public BookWebController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/")
    public  String redirectIndex(){
        return "redirect:/books";
    }

    @GetMapping("/books")
    public String index(Model model) {
        List<Book> books = bookService.findAll();
        model.addAttribute("books", books);
        return "/books/index";
    }

    @GetMapping("/books/{id}")
    public String showBook(@PathVariable Long id, Model model) {
        Book book = bookService.findById(id);
        model.addAttribute("book", book);
        if (book == null)
            return "redirect:/books";
        log.info("Showing book with id " + id);
        return "/books/show";
    }

    @GetMapping("/books/new")
    public String newBook(@ModelAttribute("book") Book book) {
        return "/books/new";
    }

    @PostMapping("/books")
    public String create(@Valid @ModelAttribute("book") Book book,
                         BindingResult result) {
        if (result.hasErrors())
            return "/books/new";
        bookService.save(book);
        return "redirect:/books";
    }

    @GetMapping("/books/{id}/edit")
    public String showEditBook(@PathVariable Long id, Model model){
        Book book = bookService.findById(id);
        if (book == null)
            return "redirect:/books";
        System.out.println(book.getId());
        model.addAttribute("book", book);
        return "/books/edit";
    }

    @PutMapping("/books/{id}/edit")
    public String editBook(@PathVariable Long id,
                           @Valid @ModelAttribute("book") Book book,
                           BindingResult result){
        if (result.hasErrors())
            return "/books/edit";

        Book bookUpdated = bookService.updateBook(
                id,
                book.getTitle(),
                book.getDescription(),
                book.getLanguage(),
                book.getNumberOfPages());

        if (bookUpdated == null)
            log.warn("Coudn't update book with id " + id);

        return "redirect:/books";
    }

    @DeleteMapping("/books/{id}")
    public String destroy(@PathVariable("id") Long id) {
        if (id != null)
            bookService.deleteBook(id);
        return "redirect:/books";
    }
}
