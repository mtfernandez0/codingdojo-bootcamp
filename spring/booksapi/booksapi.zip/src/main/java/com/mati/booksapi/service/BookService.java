package com.mati.booksapi.service;

import com.mati.booksapi.entity.Book;
import com.mati.booksapi.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {
    private final BookRepository bookRepository;

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public List<Book> findAll() {
        return bookRepository.findAll();
    }

    public Book save(Book book) {
        return bookRepository.save(book);
    }

    public Book findById(Long id) {
        Optional<Book> book = bookRepository.findById(id);
        return book.orElse(null);
    }

    /**
     * Returns the book saved or null if it does not exists.
     * @param id
     * @param title
     * @param desc
     * @param lang
     * @param numOfPages
     * @return
     */
    public Book updateBook(Long id, String title, String desc, String lang, Integer numOfPages){
        Book book = Book.builder()
                .id(id).title(title).description(desc)
                .language(lang).numberOfPages(numOfPages).build();

        return bookRepository.existsById(id) ? bookRepository.save(book) : null;
    }

    public void deleteBook(Long id){
        bookRepository.deleteById(id);
    }
}
