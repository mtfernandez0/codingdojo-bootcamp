package com.mati.lookify.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "songs")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class Song {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Length(min = 5, message = "Song name must be at least 5 characters long.")
    @NotBlank
    private String title;
    @Length(min = 5, message = "Artist name must be at least 5 characters long.")
    @NotBlank
    private String artist;
    @Range(min = 1, max = 10, message = "Rating value must be between 1 and 10.")
    @NotNull(message = "This field can not be empty.")
    private Integer rating;
}
