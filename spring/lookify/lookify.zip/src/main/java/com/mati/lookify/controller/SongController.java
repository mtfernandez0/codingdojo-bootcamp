package com.mati.lookify.controller;

import com.mati.lookify.entity.Song;
import com.mati.lookify.service.SongService;
import jakarta.validation.Valid;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Controller
@Log4j2
public class SongController {

    private final SongService songService;

    public SongController(SongService songService) {
        this.songService = songService;
    }

    @GetMapping("/")
    public String index(){
        return "index";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model){
        model.addAttribute("songs", songService.findAll());
        return "dashboard";
    }

    @GetMapping("/songs/new")
    public String newSong(@ModelAttribute("song") Song song){
        return "new";
    }

    @PostMapping("/songs/new")
    public String addNewSong(@Valid @ModelAttribute("song") Song song,
                             BindingResult result){
        if (result.hasErrors())
            return "new";

        songService.save(song);
        return "redirect:/dashboard";
    }

    @GetMapping("/songs/{id}")
    public String getSongsById(@PathVariable Long id,
                               Model model){
        Optional<Song> song;
        log.info("The id is " + id);
        if (id == null || (song = songService.findById(id)).isEmpty())
            return "redirect:/dashboard";

        model.addAttribute("song", song.get());

        return "song";
    }

    @DeleteMapping("/songs/{id}")
    public String destroy(@PathVariable Long id){
        if (id != null && songService.existsById(id))
            songService.deleteById(id);

        return "redirect:/dashboard";
    }

    /**
     * Endpoint intermedio para resolver el caso en el que exista mas de un artista
     * con un nombre similar
     * @param artist
     * @param model
     * @return
     */
    @GetMapping("/search/artist")
    public String searchByArtist(@RequestParam String artist,
                                 Model model){
        List<Song> songs;
        if (artist == null || (songs = songService.findByArtistContaining(artist)).isEmpty())
            return "redirect:/dashboard";

        model.addAttribute("searchParam", artist);
        model.addAttribute("artists", getUniqueArtistsNames(songs));
        return "artistsLike";
    }

    @GetMapping("/search/{alias}")
    public String showArtist(@PathVariable String alias,
                             @RequestParam String artist,
                             Model model){

        model.addAttribute("alias", alias);
        model.addAttribute("songs", songService.findAllByArtist(artist));
        return "artistSongs";
    }

    @GetMapping("/search/topTen")
    public String topTen(Model model){
        model.addAttribute("songs", songService.findTopTen());
        return "topTen";
    }

    private Set<String> getUniqueArtistsNames(List<Song> songs){
        Set<String> artistNames = new HashSet<>();
        for (Song s : songs)
            artistNames.add(s.getArtist());

        return artistNames;
    }
}
