package com.mati.lookify.service;

import com.mati.lookify.entity.Song;
import com.mati.lookify.repository.SongRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SongService {
    private final SongRepository songRepository;

    public SongService(SongRepository songRepository) {
        this.songRepository = songRepository;
    }

    public List<Song> findAll() {
        return songRepository.findAll();
    }

    public <S extends Song> S save(S entity) {
        return songRepository.save(entity);
    }

    public boolean existsById(Long id) {
        return songRepository.existsById(id);
    }

    public Optional<Song> findById(Long id) {
        return songRepository.findById(id);
    }

    public void deleteById(Long id) {
        songRepository.deleteById(id);
    }

    public List<Song> findByArtistContaining(String str) {
        return songRepository.findByArtistContaining(str);
    }

    public List<Song> findAllByArtist(String artist) {
        return songRepository.findAllByArtist(artist);
    }

    public List<Song> findTopTen() {
        return songRepository.findTop10ByOrderByRatingDesc();
    }
}
