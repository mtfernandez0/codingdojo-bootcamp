package com.mati.lookify.repository;

import com.mati.lookify.entity.Song;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SongRepository extends CrudRepository<Song, Long> {
    List<Song> findAll();
    @Override
    boolean existsById(Long id);

    @Override
    Optional<Song> findById(Long id);

    @Override
    void deleteById(Long id);

    List<Song> findByArtistContaining(String str);

    List<Song> findAllByArtist(String artist);

    List<Song> findTop10ByOrderByRatingDesc();
}
