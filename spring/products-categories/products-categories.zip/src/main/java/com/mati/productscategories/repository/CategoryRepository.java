package com.mati.productscategories.repository;

import com.mati.productscategories.entity.Category;
import com.mati.productscategories.entity.Product;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CategoryRepository extends CrudRepository<Category, Long> {
    List<Category> findAll();

    List<Category> findByProductsNotContains(Product product);
}
