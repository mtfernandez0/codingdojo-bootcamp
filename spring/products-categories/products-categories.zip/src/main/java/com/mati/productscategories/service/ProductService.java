package com.mati.productscategories.service;

import com.mati.productscategories.entity.Category;
import com.mati.productscategories.entity.Product;
import com.mati.productscategories.repository.CategoryRepository;
import com.mati.productscategories.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public ProductService(ProductRepository productRepository,
                          CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    public Product save(Product product){
        return productRepository.save(product);
    }

    public boolean existsById(Long id){
        return productRepository.existsById(id);
    }

    public Product findById(Long id) {
        return productRepository.findById(id).orElse(null);
    }

    public List<Product> findAllWithNoCategory(Category category){
        return productRepository.findByCategoriesNotContains(category);
    }
}
