package com.mati.productscategories.service;

import com.mati.productscategories.entity.Category;
import com.mati.productscategories.entity.Product;
import com.mati.productscategories.repository.CategoryRepository;
import com.mati.productscategories.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public CategoryService(ProductRepository productRepository,
                          CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    public Category save(Category category){
        return categoryRepository.save(category);
    }

    public boolean existsById(Long id){
        return categoryRepository.existsById(id);
    }

    public List<Category> findAllWithNoProduct(Product product){
        return categoryRepository.findByProductsNotContains(product);
    }

    public Category findById(Long id){
        return categoryRepository.findById(id).orElse(null);
    }
}
