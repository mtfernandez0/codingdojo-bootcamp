package com.mati.productscategories.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "categories")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "Name cannot be empty")
    @Size(max = 255, message = "Name must have a maximum of 255 characters")
    private String name;
    @Column(updatable=false)
    private Date created_at;
    private Date updated_at;
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "categories_products",
            joinColumns = @JoinColumn(name = "category_id"),
            inverseJoinColumns = @JoinColumn(name = "product_id")
    )
    private List<Product> products;

    @PrePersist
    public void prePersist(){
        created_at = new Date();
        updated_at = new Date();
    }

    @PreUpdate
    public void preUpdate(){
        updated_at = new Date();
    }
}
