package com.mati.productscategories.controller;

import com.mati.productscategories.entity.Category;
import com.mati.productscategories.entity.Product;
import com.mati.productscategories.service.CategoryService;
import com.mati.productscategories.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/categories")
public class CategoryController {

    private final ProductService productService;
    private final CategoryService categoryService;

    public CategoryController(ProductService productService,
                             CategoryService categoryService) {
        this.productService = productService;
        this.categoryService = categoryService;
    }

    @GetMapping("/")
    public String redirect(){
        return "redirect:/categories/new";
    }

    @GetMapping("/new")
    public String newCategory(@ModelAttribute("category") Category category){
        return "category/new";
    }

    @PostMapping("/create")
    public String createCategory(@Valid @ModelAttribute("category") Category category,
                                BindingResult result,
                                Model model){
        if (result.hasErrors()){
            model.addAttribute("category", category);
            return "category/new";
        }

        categoryService.save(category);
        return "redirect:/products/new";
    }

    @GetMapping("/{id}")
    public String addCategoryToProduct(@PathVariable Long id,
                                       Model model){
        if (!categoryService.existsById(id))
            return "redirect:/products/new";
        Category category = categoryService.findById(id);

        model.addAttribute("products", productService.findAllWithNoCategory(category));
        model.addAttribute("category", category);

        return "category/showCategory";
    }

    @PutMapping("/add/product/{category_id}")
    public String addProduct(@PathVariable Long category_id,
                              @RequestParam("product_id") Long product_id){

        Category category = categoryService.findById(category_id);
        Product product = productService.findById(product_id);

        if (category != null && product != null){
            product.getCategories().add(category);
            productService.save(product);
        }
        return "redirect:/products/new";
    }
}
