package com.mati.productscategories;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsCategoriesApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductsCategoriesApplication.class, args);
    }

}
