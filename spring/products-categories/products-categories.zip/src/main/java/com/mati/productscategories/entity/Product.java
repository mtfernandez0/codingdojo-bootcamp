package com.mati.productscategories.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "products")
@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Builder
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "Name cannot be empty")
    @Size(max = 255, message = "Name must have a maximum of 255 characters")
    private String name;
    @NotBlank(message = "Description cannot be empty")
    @Column(columnDefinition = "TEXT")
    private String description;
    @NotNull(message = "Price cannot be null")
    @DecimalMin(value = "0", message = "Price must be positive")
    private BigDecimal price;
    @Column(updatable=false)
    private Date created_at;
    private Date updated_at;
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "categories_products",
            joinColumns = @JoinColumn(name = "product_id"),
            inverseJoinColumns = @JoinColumn(name = "category_id")
    )
    private List<Category> categories;

    @PrePersist
    public void prePersist(){
        created_at = new Date();
        updated_at = new Date();
    }

    @PreUpdate
    public void preUpdate(){
        updated_at = new Date();
    }
}
