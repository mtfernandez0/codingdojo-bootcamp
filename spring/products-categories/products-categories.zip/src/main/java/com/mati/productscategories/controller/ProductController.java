package com.mati.productscategories.controller;

import com.mati.productscategories.entity.Category;
import com.mati.productscategories.entity.Product;
import com.mati.productscategories.service.CategoryService;
import com.mati.productscategories.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/products")
public class ProductController {

    private final ProductService productService;
    private final CategoryService categoryService;

    public ProductController(ProductService productService,
                             CategoryService categoryService) {
        this.productService = productService;
        this.categoryService = categoryService;
    }

    @GetMapping("/")
    public String redirect(){
        return "redirect:/products/new";
    }

    @GetMapping("/new")
    public String newProduct(@ModelAttribute("product") Product product){
        return "product/new";
    }

    @PostMapping("/create")
    public String createProduct(@Valid @ModelAttribute("product") Product product,
                                BindingResult result,
                                Model model){
        if (result.hasErrors()){
            model.addAttribute("product", product);
            return "product/new";
        }

        productService.save(product);
        return "redirect:/categories/new";
    }

    @GetMapping("/{id}")
    public String addProductToCategory(@PathVariable Long id,
                                       Model model){
        if (!productService.existsById(id))
            return "redirect:/products/new";
        Product product = productService.findById(id);

        model.addAttribute("categories", categoryService.findAllWithNoProduct(product));
        model.addAttribute("product", product);

        return "product/showProduct";
    }

    @PutMapping("/add/category/{product_id}")
    public String addCategory(@PathVariable Long product_id,
                              @RequestParam("category_id") Long category_id){

        Category category = categoryService.findById(category_id);
        Product product = productService.findById(product_id);

        if (category != null && product != null){
            product.getCategories().add(category);
            productService.save(product);
        }
        return "redirect:/products/new";
    }
}
