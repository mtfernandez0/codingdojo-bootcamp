package com.mati.counter;

import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Counter {
    @GetMapping("/")
    public String home(HttpSession session){
        int count = 0;
        if (session.getAttribute("counter") != null)
            count = (int) session.getAttribute("counter");
        count++;
        session.setAttribute("counter", count);
        return """
                <h4>Welcome User</h4>
                <a href='/counter'>See counter</a>
                <a href='/reset'>Reset counter</a>
                <a href='/double'>Double visit</a>
                """;
    }

    @GetMapping("/counter")
    public String counter(HttpSession session){
        int count = 0;
        if (session.getAttribute("counter") != null)
            count = (int) session.getAttribute("counter");
        String body =
                String.format(
                        "You have visited %s %d times",
                        "<a href='/'>http://localhost:8080</a>", count);
        return String.format("""
                    <h4>You have visited %s</h4>
                    <a href='/'>Test another visit?</a>
                    <a href='/reset'>Reset counter</a>
                    <a href='/double'>Double visit</a>
                    """, body);
    }

    @GetMapping("/double")
    public String doubleCOunter(HttpSession session){
        int count = 0;
        if (session.getAttribute("counter") != null)
            count = (int) session.getAttribute("counter");
        count+=2;
        session.setAttribute("counter", count);
        return """
                <h4>Counter incremented by 2</h4>
                <a href='/counter'>See counter</a>
                <a href='/reset'>Reset counter</a>
                <a href='/'>Test visit</a>
                """;
    }

    @GetMapping("/reset")
    public String reset(HttpSession session){
        session.removeAttribute("counter");
        return """
                <h4>Your counter has been successfully reset!</h4>
                <a href='/counter'>See counter</a>
                <a href='/'>Test visit</a>
                <a href='/double'>Double visit</a>
                """;
    }
}
