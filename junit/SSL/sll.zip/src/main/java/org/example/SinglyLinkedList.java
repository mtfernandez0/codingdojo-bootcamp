package org.example;

public class SinglyLinkedList {
    public class Node{
        public int value;
        public Node next;
        Node(int value){
            this.value = value;
            this.next = null;
        }
    }
    public Node head;
    public int size;

    public void add(int value){
        Node newNode = new Node(value);

        if(head == null){
            head = newNode;
        } else {
            Node runner = head;
            while(runner.next != null)
                runner = runner.next;

            runner.next = newNode;
        }
        size++;
    }

    public boolean remove(){
        if(head == null)
            return false;

        Node lastNode = head;
        Node runner = lastNode;

        while(lastNode.next != null){
            runner = lastNode; lastNode = lastNode.next;
        }

        runner.next = null;
        size--;

        return true;
    }

    public boolean removeAt(int index){
        if(index < 0 || index >= size || head == null)
            return false;

        if(index == 0){
            this.head = this.head.next;
            size--;
            return true;
        }

        Node lastNode = head;
        Node runner = lastNode;

        while(index > 0 && lastNode.next != null){
            runner = lastNode;
            lastNode = lastNode.next;
            index--;
        }

        runner.next = lastNode.next;
        size--;
        return true;
    }

    public boolean removeFront(){
        return removeAt(0);
    }
}
