package com.mati.auth.controller;

import com.mati.auth.entity.User;
import com.mati.auth.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/register")
    public String register(@ModelAttribute("user") User user) {
        return "register";
    }

    @PostMapping("/register")
    public String registerVerify(@Valid @ModelAttribute("user") User user,
                                 BindingResult result,
                                 Model model,
                                 RedirectAttributes redirectAttributes) {

        userService.checkCredentialsRegistration(user, result);

        if (result.hasErrors()){
            model.addAttribute("user", user);
            return "register";
        }

        userService.register(user);

        redirectAttributes.addFlashAttribute(
                "register",
                "Registration successfully!"
        );

        return "redirect:/login";
    }

    @GetMapping("/login")
    public String login(@RequestParam(value = "error", required = false) Object error,
                        HttpSession session,
                        Model model) {

        if (session.getAttribute("email") != null){
            model.addAttribute("email", session.getAttribute("email"));
            session.removeAttribute("email");
        }
        return "login";
    }
}
