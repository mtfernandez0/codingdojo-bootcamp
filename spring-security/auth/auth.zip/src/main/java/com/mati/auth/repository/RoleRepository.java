package com.mati.auth.repository;

import com.mati.auth.entity.Role;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface RoleRepository extends CrudRepository<Role, Long> {

    Role findByName(String name);

    @Query(
            value = "SELECT COUNT(*) " +
            "FROM users_roles AS ur " +
            "WHERE ur.role_id = 2",
            nativeQuery = true
    )
    int countNumberOfAdmins();
}
