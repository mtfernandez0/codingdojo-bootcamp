package com.mati.auth.repository;

import com.mati.auth.entity.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {

    User findByEmail(String email);

    @Override
    long count();

    @Query(
            value = "SELECT u.* " +
                    "FROM users AS u " +
                    "JOIN users_roles AS ur ON ur.user_id = u.id " +
                    "WHERE ur.role_id != 3 " +
                    "GROUP BY u.id",
            nativeQuery = true
    )
    List<User> findAllNoSuperAdmin();
}
