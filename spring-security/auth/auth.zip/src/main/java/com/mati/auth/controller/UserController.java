package com.mati.auth.controller;

import com.mati.auth.entity.User;
import com.mati.auth.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class UserController {
    private final UserService userService;
    private static final String FORMAT_DATE = "MMM dd'th', YYYY";

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/")
    public String redirect(){
        return "redirect:/dashboard";
    }

    @GetMapping("/dashboard")
    public String dashboard(Principal principal, Model model, HttpSession session) {
        String email = principal.getName();

        User user = userService.findByEmail(email);

        model.addAttribute("signUp", new SimpleDateFormat(FORMAT_DATE).format(user.getCreatedAt()));
        model.addAttribute("signIn",
                new SimpleDateFormat(FORMAT_DATE).format(new Date(session.getCreationTime())));
        model.addAttribute("currentUser", user);
        return "dashboard";
    }
}
