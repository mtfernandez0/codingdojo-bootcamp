package com.mati.auth.controller;

import com.mati.auth.entity.User;
import com.mati.auth.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    public final UserService userService;

    public AdminController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping(value = {"", "/"})
    public String adminTable(Principal principal, Model model) {
        String email = principal.getName();
        model.addAttribute("currentUser", userService.findByEmail(email));
        model.addAttribute("users", userService.findAllNoSuperAdmin());
        return "adminPage";
    }

    @PutMapping("/add-admin-role/{id}")
    public String addAdminRole(@PathVariable Long id){
        User user = userService.findById(id).orElse(null);

        if (user != null && user.hasRole("USER"))
            userService.addRole(user, "ROLE_ADMIN");

        return "redirect:/admin";
    }

    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id){
        User user = userService.findById(id).orElse(null);

        if (user == null || (user.hasRole("ADMIN") && !principalHasRole("ROLE_SUPER_ADMIN")))
            return "redirect:/dashboard";

        userService.remove(user);

        return "redirect:/admin";
    }

    private boolean principalHasRole(String roleName){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        List<SimpleGrantedAuthority> authorities = (List<SimpleGrantedAuthority>) auth.getAuthorities();

        return authorities.stream().anyMatch(r -> r.getAuthority().equals(roleName));
    }
}
