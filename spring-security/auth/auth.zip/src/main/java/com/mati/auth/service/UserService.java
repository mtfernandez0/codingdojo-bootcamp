package com.mati.auth.service;

import com.mati.auth.entity.Role;
import com.mati.auth.entity.User;
import com.mati.auth.repository.RoleRepository;
import com.mati.auth.repository.UserRepository;
import com.mati.auth.validator.UserValidator;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserValidator userValidator;

    public UserService(UserRepository userRepository,
                       RoleRepository roleRepository,
                       PasswordEncoder passwordEncoder,
                       UserValidator userValidator) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.userValidator = userValidator;
    }

    public Optional<User> findById(Long aLong) {
        return userRepository.findById(aLong);
    }

    public User findByEmail(String email){
        return userRepository.findByEmail(email);
    }

    public List<User> findAllNoSuperAdmin(){
        return userRepository.findAllNoSuperAdmin();
    }

    private void setRole(User user){
        if (userRepository.count() == 0)
            user.setRoles(List.of(roleRepository.findByName("ROLE_SUPER_ADMIN")));
        else if (roleRepository.countNumberOfAdmins() == 0)
            user.setRoles(List.of(roleRepository.findByName("ROLE_ADMIN")));
        else
            user.setRoles(List.of(roleRepository.findByName("ROLE_USER")));
    }

    public User register(User user){
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        setRole(user);

        return userRepository.save(user);
    }

    public boolean checkCredentialsExistance(User user){
        return Objects.nonNull(user) &
                Objects.nonNull(user.getEmail()) &
                Objects.nonNull(user.getPassword()) &
                Objects.nonNull(user.getPasswordConfirmation());
    }

    public void checkCredentialsRegistration(User user,
                                             BindingResult result){

        if (!checkCredentialsExistance(user)) return;

        if (Objects.nonNull(findByEmail(user.getEmail())))
            result.rejectValue(
                    "email",
                    "Match"
            );

        userValidator.validate(user, result);
    }

    public User addRole(User user, String roleName){
        Role role = roleRepository.findByName(roleName);
        user.getRoles().add(role);

        return userRepository.save(user);
    }

    public void remove(User user){
        userRepository.delete(user);
    }
}
