import com.classes.*;

public class HumanTest {
    public static void main(String[] args) {
        Human human = new Human();
        Samurai samurai = new Samurai();
        Samurai samurai2 = new Samurai();
        Samurai samurai3 = new Samurai();
        Wizard wizard = new Wizard();
        Ninja ninja = new Ninja();

        samurai.howMany();
        ninja.steal(samurai);
        ninja.runAway();
        samurai.deathBlow(ninja);
        samurai.howMany();
        samurai.meditate();
        wizard.fireBall(samurai);
        wizard.heal(wizard);
        samurai.deathBlow(wizard);
        samurai.howMany();
        samurai.meditate();
        human.attack(samurai);
        samurai.deathBlow(human);
        samurai.howMany();
        samurai.meditate();

        System.out.printf("There are %d samurais!\n", samurai.howMany());
    }
}