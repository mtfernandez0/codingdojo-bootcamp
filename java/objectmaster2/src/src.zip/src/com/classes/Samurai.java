package com.classes;

public class Samurai extends Human{
    private int bodies;
    public Samurai() {
        super();
        setHealth(200);
        bodies = 0;
    }

    public void deathBlow(Human human){
        System.out.println("I have killed you, but at what cost...");
        human.setHealth(0);
        this.setHealth(this.getHealth()/2);
        bodies++;
    }

    public void meditate(){
        System.out.println("Time to rest");
        setHealth(getHealth()*2);
    }
    public int howMany(){
        if (bodies == 0)
            System.out.println("My hands are clean.");
        else if(bodies == 1)
            System.out.println("The first one is always the one you remember the most...");
        else
            System.out.println("I am unstoppable.");
        return bodies;
    }
}
