package com.classes;

public class Wizard extends Human{
    public Wizard() {
        super(3, 8, 3, 50);
    }

    public void heal(Human human){
        System.out.println("Healing!");
        human.setHealth(human.getHealth() + this.getIntelligence());
    }

    public void fireBall(Human human){
        System.out.println("Fireball!");
        human.setHealth(human.getHealth() + this.getIntelligence() * 3);
    }
}
