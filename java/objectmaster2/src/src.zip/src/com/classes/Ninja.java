package com.classes;

public class Ninja extends Human{
    public Ninja() {
        super();
        setStealth(10);
    }

    public void steal(Human human){
        int points = human.getHealth() - this.getStealth();
        human.setHealth(points);
        this.setHealth(this.getHealth() + this.getStealth());
        System.out.println("Stealing silently!");
    }

    public void runAway(){
        System.out.println("Running away silently!");
        setHealth(getHealth() - 10);
    }
}
