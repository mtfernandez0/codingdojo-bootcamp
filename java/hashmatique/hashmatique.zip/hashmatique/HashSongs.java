import java.util.HashMap;
import java.util.Map.Entry;

public class HashSongs{
    public static void main(String[] args) {
        HashMap<String, String> trackList = new HashMap<String, String>();

        trackList.put("Monolith", "Mercy, Mercy");
        trackList.put("The Valley", "Circle down to the mounth of the valley");
        trackList.put("Ode to Physical Pain", "My surest, truest friend");
        trackList.put("Strange Ways", "In such strange ways");

        for (Entry<String, String> entry : trackList.entrySet())
            System.out.printf("%s: %s\n", entry.getKey(), entry.getValue());
    }
}