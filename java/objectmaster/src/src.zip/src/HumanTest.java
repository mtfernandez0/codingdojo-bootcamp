import com.classes.*;

public class HumanTest {
    public static void main(String[] args) {
        Human human = new Human();
        Samurai samurai = new Samurai();

        System.out.println(human);
        System.out.println(samurai);

        samurai.attack(human);
        System.out.println(human);

    }
}