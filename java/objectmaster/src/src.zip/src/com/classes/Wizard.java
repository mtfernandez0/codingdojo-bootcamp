package com.classes;

public class Wizard extends Human{
    public Wizard() {
        System.out.println("I'm the default wizard!");
    }

    public void wizardMethod(){
        System.out.println("this is the wizard's method");
    }
}
