package com.classes;

public class Samurai extends Human{
    public Samurai() {
        System.out.println("I'm the default samurai!");
    }
}
