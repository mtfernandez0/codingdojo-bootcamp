package com.classes;

public class Ninja extends Human{
    public Ninja() {
        System.out.println("I'm the default ninja!");
    }
}
