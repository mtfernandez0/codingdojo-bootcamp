import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

public class PuzzleJava{
    public static void main(String[] args) {
        ArrayList<Integer> arrayList = greaterThanX(15, 10);
        System.out.println(arrayList);
        System.out.println(largerThanFiveLetters());
        createArrayOfLetters();
        System.out.println(generateAndReturn());
        generateAndReturnSorted();
        System.out.println(generateRandomString());
        System.out.println(generateRandomStrings());
    }

    //1
    public static ArrayList<Integer> greaterThanX(int size, int x){
        Random random = new Random();
        int[] array = new int[size];

        array = random.ints(size, 0, x + 10).toArray();

        ArrayList<Integer> res = new ArrayList<Integer>();

        for (int num : array)
            if(num > x) res.add(num);

        return res;
    }

    //2
    public static ArrayList<String> largerThanFiveLetters(){
        ArrayList<String> names = new ArrayList<>(Arrays.asList("Nancy", "Mike", "Jinichi", "Fujibayashi", "Momochi", "Ishikawa"));
        Collections.shuffle(names);
        System.out.println(names);
        ArrayList<String> res = new ArrayList<>();

        for (String name : names) 
            if(name.length() > 5) res.add(name);
        
        return res;
    }

    //3
    public static void createArrayOfLetters(){
        ArrayList<Character> letterList = new ArrayList<Character>();
        ArrayList<Character> vowels = new ArrayList<Character>(Arrays.asList('A', 'E', 'I', 'O', 'U'));

        for (int i = 0; i < 26; i++)
            letterList.add((char) (i + 65));
        
        Collections.shuffle(letterList);

        System.out.printf("First letter is: %c and last letter is: %c\n", letterList.get(0), letterList.get(25));

        if(vowels.contains(letterList.get(0)))
            System.out.println("The first letter is effectively a vowel!");
    }

    //4
    public static ArrayList<Integer> generateAndReturn(){
        Random random = new Random();
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        int[] array = random.ints(10, 55, 101).toArray();

        for (int num : array)
            arrayList.add(num);
        
        return arrayList;
    }

    //5
    public static ArrayList<Integer> generateAndReturnSorted(){
        Random random = new Random();
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        int[] array = random.ints(10, 55, 101).toArray();

        for (int num : array)
            arrayList.add(num);

        Collections.sort(arrayList);
        System.out.println(arrayList);

        System.out.printf("Min is: %d and max is: %d\n", arrayList.get(0), arrayList.get(arrayList.size() - 1));

        return arrayList;
    }

    //6
    public static String generateRandomString(){
        Random random = new Random();
        String randomString = "";

        for (int i = 0; i < 5; i++) {
            char c = (char) (random.nextInt(26) + 65);
            randomString += c;
        }

        return randomString;
    }

    //7
    public static ArrayList<String> generateRandomStrings(){
        ArrayList<String> randomStrings = new ArrayList<String>(); 
        for (int i = 0; i < 10; i++)
            randomStrings.add(generateRandomString());

        return randomStrings;
    }
}