import com.mati.entity.Calculator;

public class Main {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        calculator.performOperation(12);
        calculator.performOperation(125);
        calculator.performOperation("/");
        calculator.performOperation(5);
        calculator.performOperation("*");
        calculator.performOperation(2);
        calculator.performOperation("+");
        calculator.performOperation(12);
        calculator.performOperation("-");
        calculator.performOperation(7);
        calculator.performOperation("=");

        System.out.println("result: " + calculator.getResult());

        calculator.performOperation(5);
        calculator.performOperation("*");
        calculator.performOperation(2);
        calculator.performOperation("-");
        calculator.performOperation(12.95);
        calculator.performOperation("=");

        System.out.println("result: " + calculator.getResult());

        calculator.performOperation("asa");
        // "asa" no es una operación válida, por lo que tira error
        calculator.performOperation(12.95);
    }
}