package com.mati.entity;

public class Calculator extends AbstractCalculator{
    private String operation;
    private double result;
    private boolean ready;
    public Calculator() {
        operation = "";
        result = 0;
    }

    public Calculator performOperation(String op){
        if (!(ready = op.equals("=")))
            operation = op;
        else
            operation = "";
        return this;
    }

    public Calculator performOperation(double num){
        switch (operation) {
            case "" -> result = num;
            case "+" -> result = sum(result, num);
            case "-" -> result = rest(result, num);
            case "*" -> result = multiply(result, num);
            case "/" -> result = divide(result, num);
            default -> throw new IllegalArgumentException(operation + " is not a valid operation.");
        }
        return this;
    }

    public double getResult() {
        if (ready) {
            ready = false;
            return result;
        }

        System.out.println("No result to be displayed.");
        return 0;
    }
}
