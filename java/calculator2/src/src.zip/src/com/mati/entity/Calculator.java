package com.mati.entity;

public class Calculator extends AbstractCalculator{
    private String operation;
    private double result;
    private boolean ready;
    public Calculator() {
        operation = "";
        result = 0;
    }

    public void performOperation(String op){
        if (!(ready = op.equals("=")))
            operation = op;
        else
            operation = "";
        System.out.println(ready);
    }

    public void performOperation(double num){
        switch (operation) {
            case "" -> result = num;
            case "+" -> result = sum(result, num);
            case "-" -> result = rest(result, num);
            case "*" -> result = multiply(result, num);
            case "/" -> result = divide(result, num);
            default -> throw new IllegalArgumentException(operation + " is not a valid operation.");
        }
    }

    public double getResult() {
        if (ready) {
            ready = false;
            return result;
        }

        System.out.println("No result to be displayed.");
        return 0;
    }
}
