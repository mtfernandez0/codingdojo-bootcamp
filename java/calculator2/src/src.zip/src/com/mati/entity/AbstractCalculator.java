package com.mati.entity;

public abstract class AbstractCalculator {
    protected double sum(double a, double b){
        return a + b;
    }
    protected double rest(double a, double b){
        return a - b;
    }
    protected double multiply(double a, double b){
        return a * b;
    }
    protected double divide(double a, double b) {
        if (b == 0)
            throw new ArithmeticException("Trying to divide by 0.");
        return a / b;
    }
}
