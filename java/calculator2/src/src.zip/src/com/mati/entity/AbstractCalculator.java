package com.mati.entity;

public abstract class AbstractCalculator {
    protected double sum(double a, double b){
        return a + b;
    }
    protected double rest(double a, double b){
        return a - b;
    }
    protected double multiply(double a, double b){
        return a * b;
    }

    /**
     * A class can choose weather or not to implement any exception for division zero
     * @param a
     * @param b
     * @return
     */
    protected abstract double divide(double a, double b);
}
