public class StringManipulator{
    public String trimAndConcat(String str1, String str2){
        return str1.trim().concat(str2.trim());
    }

    public int getIndexOrNull(String str1, char c){
        // devuelve -1 por defecto en caso de que no se encuentre c
        return str1.indexOf(c);
    }

    public String concatSubstring(String str1, int begin, int end, String str2){
        if(begin > end || end >= str1.length())
            System.err.println("The indices are not appropriate!");
        return str1.substring(begin, end).concat(str2);
    }
}