public class StringManipulatorTesting{
    public static void main(String[] args) {
        trimAndConcatTest("    Hola     ","     Mundo    ");
        getIndexOrNullTest("Paracetamol600", '1');
        concatSubstringTest("Reacondicionar", 2, 5, "razado");
    }

    public static void trimAndConcatTest(String str1, String str2){
        StringManipulator manipulator = new StringManipulator();
        System.out.printf("Testing trimAndConcat with '%s' and '%s'...\n", str1, str2);
        System.out.println(manipulator.trimAndConcat(str1, str2));
    }

    public static void getIndexOrNullTest(String str1, char letter){
        StringManipulator manipulator = new StringManipulator();
        System.out.printf("Testing getIndexOrNull with '%s' and %c...\n", str1, letter);
        System.out.println(manipulator.getIndexOrNull(str1, letter));
    }

    public static void concatSubstringTest(String str1, int begin, int end, String str2){
        StringManipulator manipulator = new StringManipulator();
        System.out.printf("Testing concatSubstring with '%s' %d %d '%s'...\n", str1, begin, end, str2);
        System.out.println(manipulator.concatSubstring(str1, begin, end, str2));
    }
}