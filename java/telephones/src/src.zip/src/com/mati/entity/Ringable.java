package com.mati.entity;

public interface Ringable {
    String ring();
    String unlock();
}
