import java.util.ArrayList;
import java.lang.ClassCastException;

public class ExceptionListTest{
    public static void main(String[] args) {
        ExceptionList exceptionList = new ExceptionList();

        ArrayList<Object> list = exceptionList.generateArrayObj();

        int i = 0;
        try {
            while(i < list.size()){
                int castedValue = (int) list.get(i);
                i++;
            }
        } catch (ClassCastException e) {
            System.out.printf("ClassCastException: trying to convert an object of type %s to an int\n", list.get(i).getClass().getSimpleName());
            System.out.printf("The error occurred at index %d\n", i);
            System.out.println("The object that caused the exception was [" + list.get(i) + "].");
        }
    }
}