import java.util.ArrayList;

public class ExceptionList{
    public ArrayList<Object> generateArrayObj(){
        ArrayList<Object> list = new ArrayList<Object>();
        list.add("13");
        list.add("Hola Mundo");
        list.add(48);
        list.add("Adios Mundo");

        return list;
    }
}