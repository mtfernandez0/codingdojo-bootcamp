public class Gorilla extends Mammal{
    public void throwSomething(){
        System.out.println("Throwing a barrel at the wall!");
        setEnergyLevel(getEnergyLevel() - 5);
    }

    public void eatBananas(){
        System.out.println("Eating a banana!");
        setEnergyLevel(getEnergyLevel() + 10);
    }

    public void climb(){
        System.out.println("Climbing the highest tree!");
        setEnergyLevel(getEnergyLevel() - 10);
    }
}