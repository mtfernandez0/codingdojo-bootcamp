import com.lifeforms.Bat;

public class BatTest {
    public static void main(String[] args) {
        Bat bat = new Bat();
        bat.displayEnergy();

        bat.attackTown();
        bat.attackTown();
        bat.attackTown();

        bat.displayEnergy();

        bat.eatHumans();
        bat.eatHumans();

        bat.displayEnergy();

        bat.fly();
        bat.fly();

        bat.displayEnergy();
    }
}