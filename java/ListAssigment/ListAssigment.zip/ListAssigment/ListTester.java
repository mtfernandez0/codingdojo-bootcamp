public class ListTester{
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();
        System.out.println("Empty list: " + list);
        list.add(1);
        list.add(2);
        System.out.println("List with two values: " + list);
        System.out.println(list.find(2).value);
        list.remove();
        System.out.println(list.find(1).value);
        System.out.println("List after removing one value: " + list);
        list.add(15);
        list.add(59);
        list.add(-22);
        list.add(19);
        System.out.println("List with five elements: " + list);
        list.removeAt(3);
        System.out.println("List after removing the fourth item: " + list);
    }
}