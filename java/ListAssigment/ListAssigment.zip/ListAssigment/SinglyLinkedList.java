public class SinglyLinkedList{
    private Node head;
    private int size;

    SinglyLinkedList(){
        this.head = null;
        size = 0;
    }

    public int getSize(){
        return this.size;
    }

    public Node getHead(){
        return this.head;
    }

    public void add(int value){
        Node newNode = new Node(value);
        
        if(head == null){
            head = newNode;
        } else {
            Node runner = head;
            while(runner.next != null)
                runner = runner.next;

            runner.next = newNode;
        }
        size++;
    }

    public boolean remove(){
        if(head == null)
            return false;

        Node lastNode = head;
        Node runner = lastNode;

        while(lastNode.next != null){
            runner = lastNode; lastNode = lastNode.next;
        }
        
        runner.next = null;
        size--;

        return true;
    }

    public Node find(int value){
        if(head == null)
            return null;
        
        Node runner = head;

        while(runner != null && runner.value != value)
            runner = runner.next;

        return runner;
    }

    public boolean removeAt(int index){
        if(index < 0 || index >= size || head == null)
            return false;

        if(index == 0){
            this.head = this.head.next;
            size--;
            return true;
        }

        Node lastNode = head;
        Node runner = lastNode;

        while(index > 0 && lastNode.next != null){
            runner = lastNode;
            lastNode = lastNode.next;
            index--;
        }

        runner.next = lastNode.next;
        size--;
        return true;
    }

    public String toString(){
        String res = "";
        
        if(size == 0) return res;
        res += "[";

        Node runner = head;
        int i = 0;
        while(i < this.size - 1){
            res += runner.value + ", ";
            runner = runner.next;
            i++;
        }
        res += runner.value + "]";
        return res;
    }

}