public class Node{
    public int value;
    public Node next;
    Node(int value){
        this.value = value;
        this.next = null;
    }
}