package com.mati;

import java.util.ArrayList;
import java.util.List;

public class Pokedex extends AbstractPokemon{
    private List<Pokemon> myPokemons = new ArrayList<>();

    public Pokedex() {}

    public Pokemon addPokemon(String name, int health, String type){
        Pokemon pokemon = createPokemon(name, health, type);
        myPokemons.add(pokemon);
        return pokemon;
    }

    @Override
    public void listPokemon() {
        myPokemons.forEach(pokemon -> System.out.println(pokemonInfo(pokemon)));
    }
}
