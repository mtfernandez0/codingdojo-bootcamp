import com.mati.Pokedex;
import com.mati.Pokemon;

public class Main {
    public static void main(String[] args) {
        Pokedex pokedex = new Pokedex();
        Pokemon charizard = pokedex.addPokemon("Charizard", 2400, "fire");
        Pokemon pikachu = pokedex.addPokemon("Pikachu", 5000, "ray");

        charizard.attackPokemon(pikachu);

        pokedex.listPokemon();
    }
}