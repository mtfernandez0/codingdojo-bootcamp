public class ProjectTest{
    public static void main(String[] args) {
        Project project = new Project(
            "Matias", 
            "Name's Matias, 23 years old, Computer Science student", 
            23.498d);
        System.out.println(project.elevatorPitch());
        
        Project project2 = new Project("Robert");
        project2.setInitialCost(23.44);
        
        Project project3 = new Project("Julia", "Name's Roberts", 67.99);

        Portfolio portfolio = new Portfolio();
        portfolio.getProject().add(project);
        portfolio.getProject().add(project2);
        portfolio.getProject().add(project3);

        portfolio.showPortfolio();
    }
}