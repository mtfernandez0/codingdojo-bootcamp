import java.util.ArrayList;

public class Portfolio{
    private ArrayList<Project> projects;

    Portfolio(){
        projects = new ArrayList<>();
    }

    Portfolio(ArrayList<Project> projects){
        this.projects = projects;
    }

    public ArrayList<Project> getProject(){
        return this.projects;
    }

    public void setProject(ArrayList<Project> projects){
        this.projects = projects;
    }

    public void showPortfolio(){
        double total = 0;
        for (Project project : projects) {
            System.out.println(project.elevatorPitch());
            total += project.getInitialCost();
        }
        System.out.println("Total cost: " + total);
    }

}