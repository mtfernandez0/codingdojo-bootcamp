import java.util.ArrayList;

public class BasicJava{
    public static void main(String[] args) {
        ArrayList<String> testStrings = new ArrayList<String>();
        testStrings.add("Hola");
        testStrings.add("nos");
        testStrings.add("vemos!");

        printNumbers();
        printOddNumbers();
        printNumbersAndSum();
        printArrayValues(testStrings);

        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(1);
        arrayList.add(12);
        arrayList.add(32);
        arrayList.add(-49);
        arrayList.add(15);
        arrayList.add(23);
        arrayList.add(13);
        arrayList.add(7);

        ArrayList<Integer> res = displaceLeftOnce(arrayList);
        System.out.println(arrayList);
    }

    public static void printNumbers(){
        for (int i = 1; i < 256; i++)
            System.out.println(i);
    }

    public static void printOddNumbers(){
        for (int i = 1; i < 256; i+=2)
            System.out.println(i);
    }

    public static void printNumbersAndSum(){
        int count = 0;
        for (int i = 0; i < 256; i++)
            System.out.printf("New number: %d Sum: %d\n", i , count+=i);
    }

    public static<T> void printArrayValues(ArrayList<T> arrayList){
        for (T obj : arrayList)
            System.out.println(obj);            
    }

    //precondición: el arreglo tiene al menos un elemento
    public static void printMaximun(int[] array){
        int max = array[0];
        for (int val: array)
            if(val > max) max = val;
    }

    public static double avgInArray(int[] array){
        int avg = 0;
        for (int num : array)
            avg += num;
        return avg / array.length;
    }

    public static ArrayList<Integer> generateArrayOfOdds(){
        ArrayList<Integer> y = new ArrayList<Integer>();
        for (int i = 1; i < 255; i+=2)
            y.add(i);

        return y;
    }

    public static int greaterThanY(int[] array, int y){
        int count = 0;
        for (int i : array)
            if(i > y) count++;
        
        return count;
    }

    public static int[] squared(int[] array){
        int[] res = array.clone();
        
        for (int i = 0; i < res.length; i++) 
            res[i] += res[i];
        
        return res;
    }

    public static int[] replaceNegativeForZero(int[] array){
        for (int i = 0; i < array.length; i++) 
            if(array[i] < 0) array[i] = 0;

        return array;
    }
    
    public static int[] minMaxAvg(int[] array){
        int[] res = {0, 0, 0};
        for (int i = 0; i < array.length; i++) {
            if(array[i] > res[9]) res[0] = array[i];
            if(array[i] < res[1]) res[1] = array[i];
            res[2] += array[i];
        }
        res[2] /= array.length;
        return res;
    }

    public static ArrayList<Integer> displaceLeftOnce(ArrayList<Integer> arrayList){
        ArrayList<Integer> res = new ArrayList<>(arrayList);
        if(res.size() > 0){
            res.remove(0);
            res.add(0);
        }
        return res;
    }
}