package com.mati.entity;

public class BankAccount {
    private String accountNumber;
    private double checkingAccountBalance;
    private double savingsAccountBalance;
    private static int totalBankAccounts = 0;
    private static double totalMoneyDeposited = 0;

    public BankAccount() {
        generateRandomAccountNumber();
        totalBankAccounts++;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getCheckingAccountBalance() {
        return checkingAccountBalance;
    }

    public double getSavingsAccountBalance() {
        return savingsAccountBalance;
    }

    public static int getTotalBankAccounts() {
        return totalBankAccounts;
    }

    public static double getTotalMoneyDeposited() {
        return totalMoneyDeposited;
    }

    public void depositCheckingAccount(double amount) {
        checkingAccountBalance += amount;
        totalMoneyDeposited += amount;
    }

    public void depositSavingsAccount(double amount) {
        savingsAccountBalance += amount;
        totalMoneyDeposited += amount;
    }

    public double withdrawFromCheckingAccount(double amount){
        if (checkingAccountBalance < amount){
            System.out.printf("Your balance of %f is insufficient to withdraw %f dollars.\n", checkingAccountBalance, amount);
            return 0;
        }
        else{
            checkingAccountBalance -= amount;
            System.out.printf("Your checking account balance is %f dollars.\n", checkingAccountBalance);
            totalMoneyDeposited -= amount;
        }
        return amount;
    }

    public double withdrawFromSavingsAccount(double amount) {
        if (savingsAccountBalance < amount){
            System.out.printf("Your balance of %f is insufficient to withdraw %f dollars.\n", savingsAccountBalance, amount);
            return 0;
        }
        else{
            savingsAccountBalance -= amount;
            System.out.printf("Your savings account balance is %f dollars.\n", savingsAccountBalance);
            totalMoneyDeposited -= amount;
        }
        return amount;
    }

    private void generateRandomAccountNumber(){
        int digitsCount = String.valueOf(totalBankAccounts).length();
        accountNumber = "";
        for (int i = 0; i < 10 - digitsCount; i++)
            accountNumber += "0";
        accountNumber += String.valueOf(totalBankAccounts);
    }
}
