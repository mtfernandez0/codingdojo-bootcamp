import com.mati.entity.BankAccount;

public class Main {
    public static void main(String[] args) {
        BankAccount user1 = new BankAccount();
        BankAccount user2 = new BankAccount();
        System.out.printf("Total bank accounts: %d\n", BankAccount.getTotalBankAccounts());

        System.out.printf("User account number: %s\n",user1.getAccountNumber());
        System.out.printf("User account number: %s\n",user2.getAccountNumber());

        user2.withdrawFromSavingsAccount(30.24);
        user2.depositSavingsAccount(40);
        user2.withdrawFromSavingsAccount(30.24);

        user1.depositCheckingAccount(103.98);
        user1.withdrawFromCheckingAccount(10.25);
        System.out.printf("Total money deposited: %f\n", BankAccount.getTotalMoneyDeposited());
    }
}