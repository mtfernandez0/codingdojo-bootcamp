import com.mati.entity.Calculator;

public class Main {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();

        calculator.setOperandOne(2.2);
        calculator.setOperandTwo(43);
        calculator.setOperation("-");
        calculator.performOperation();
        System.out.println("Result: " + calculator.getResult());
    }
}
