package com.mati.entity;

public class BasicCalculator {
    protected double sum(double a, double b){
        return a + b;
    }
    protected double rest(double a, double b){
        return a - b;
    }
}
