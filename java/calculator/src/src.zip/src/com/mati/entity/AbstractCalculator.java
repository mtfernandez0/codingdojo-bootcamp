package com.mati.entity;

import java.util.Arrays;

public abstract class AbstractCalculator {
    protected double sum(double a, double b){
        return a + b;
    }

    protected double sumAll(double[] nums){
        return Arrays.stream(nums).sum();
    }

    protected double rest(double a, double b){
        return a - b;
    }

    protected double restAll(double[] nums){
        double result = 0;
        for (double num : nums) {
            result -= num;
        }
        return result;
    }
}
