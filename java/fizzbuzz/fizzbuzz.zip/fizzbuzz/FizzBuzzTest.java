public class FizzBuzzTest{
    public static void main(String[] args) {
        FizzBuzz fizzBuzz = new FizzBuzz();

        int number = (int) (Math.random() * 100);

        System.out.printf("Resultado para el número %d: %s.\n", number, fizzBuzz.fizzbuzz(number));
    }
}