public class FizzBuzz{
    public String fizzbuzz(int number){
        String res = "";

        if(number % 3 == 0)
            res += "Fizz";

        if(number % 5 == 0)
            res += "Buzz";


        if(number % 3 != 0 && number % 5 != 0)
            res += number;

        return res;
    }
}